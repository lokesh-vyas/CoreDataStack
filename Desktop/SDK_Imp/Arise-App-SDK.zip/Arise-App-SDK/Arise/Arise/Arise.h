//
//  Arise.h
//  Arise
//
//  Created by Lokesh Vyas on 08/07/21.
//

#import <Foundation/Foundation.h>

//! Project version number for Arise.
FOUNDATION_EXPORT double AriseVersionNumber;

//! Project version string for Arise.
FOUNDATION_EXPORT const unsigned char AriseVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Arise/PublicHeader.h>


