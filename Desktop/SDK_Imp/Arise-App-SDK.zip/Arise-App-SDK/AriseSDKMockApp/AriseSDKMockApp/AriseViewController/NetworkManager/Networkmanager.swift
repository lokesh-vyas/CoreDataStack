//
//  Networkmanager.swift
//  AriseMIB
//
//  Created by Lokesh Vyas on 29/07/21.


import Foundation

public struct Connectivity {
    static let sharedInstance = NetworkReachabilityManager()!
    public static var isConnectedToInternet:Bool {
        return self.sharedInstance.isReachable
    }
}

