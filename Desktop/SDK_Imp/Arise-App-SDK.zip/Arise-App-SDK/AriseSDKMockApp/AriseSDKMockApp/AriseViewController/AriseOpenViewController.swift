//
//  AriseOpenViewController.swift
//  AriseSDKMockApp
//
//  Created by Lokesh Vyas on 25/10/21.
//

import UIKit
import AriseSDK

class AriseOpenViewController: UIViewController {
    var tempToken : [String:String]?
    
    @IBOutlet weak var customerID: UILabel!
    @IBOutlet weak var timeOut: UILabel!
    @IBOutlet weak var lblSeletedEnv: UILabel!
    @IBOutlet weak var lblSelectedLang: UILabel!
    var isSDKLogout = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if isSDKLogout == true {
            NucleiAriseRouter.doSDKLogout()
        }
        
        self.customerID.text = AppState.shared.customerID
        self.lblSeletedEnv.text = AppState.shared.environment
        
        if AppState.shared.language == "ar" {
            self.lblSelectedLang.text = "Arabic"
        } else {
            self.lblSelectedLang.text = "English"
        }
        
        switch AppState.shared.timeOut {
        case 120000.0:
            self.timeOut.text = "2 min"
            break
        case 300000.0:
            self.timeOut.text = "5 min"
            break
        case 600000.0:
            self.timeOut.text = "10 min"
            break
        default:
            self.timeOut.text = "5 min"
        }
        
        switch AppState.shared.environment {
        case "UAT":
            NucleiAriseSdkConfig()
                .configSetup(with: self)
                .setKey(EnvironmentConfiguration.partnerKey())
                .setDeviceId(UIDevice.current.identifierForVendor?.uuidString ?? "DEVICE_ID")
                .setAriseSdkUrl("https://arise-preprod-sdk.gonuclei.com/")
                .setLanguage(AppState.shared.language)
                .enableLogs(true)
                .setIdlePopupTimer(AppState.shared.timeOut,600000)
        case "PROD":
            NucleiAriseSdkConfig()
                .configSetup(with: self)
                .setKey(EnvironmentConfiguration.partnerKey())
                .setDeviceId(UIDevice.current.identifierForVendor?.uuidString ?? "DEVICE_ID")
                .setAriseSdkUrl("https://arise-sdk.gonuclei.com/")
                .setLanguage(AppState.shared.language)
                .enableLogs(true)
                .setIdlePopupTimer(AppState.shared.timeOut,600000)
        case "DEV":
            NucleiAriseSdkConfig()
                .configSetup(with: self)
                .setKey(EnvironmentConfiguration.partnerKey())
                .setDeviceId(UIDevice.current.identifierForVendor?.uuidString ?? "DEVICE_ID")
                .setAriseSdkUrl("https://arise-dev-sdk.gonuclei.com/")
                .setLanguage(AppState.shared.language)
                .enableLogs(true)
                .setIdlePopupTimer(AppState.shared.timeOut,600000)
        default:
            break
        }
        // Do any additional setup after loading the view.
    }
    
    @IBAction func openArise(_ sender: Any) {
        
        NucleiAriseRouter.open(completion: {
            (error) in
            print("error in opening Arise SDK")
        })
    }
}

extension AriseOpenViewController: NucleiArisePartnerConfig {
    
    func isPartnerApplicationLoggedIn() -> Bool {
        return true
    }
    
    func onAriseSdkSeamlessLoginRequest(seamlessRequestData: [String : String]) {
        
        SeamlessLogin().generateToken(customerID: AppState.shared.customerID,parameters: seamlessRequestData, onCompletion: { (token) in
            
            NucleiAriseRouter.validateToken(params: token) { (error) in
                if(error != nil) {
                    print("Opened Arise SDK successfully")
                }else {
                    print("Failed to open Arise SDK")
                }
            }
        }, onFail: { (error) in
            NucleiAriseRouter.fetchProvisionalTokenFailed(errorMessage: error)
        })
        print(#function)
    }
    
    func onAriseAuthenticationRequest() {
        if let token = self.tempToken {
            NucleiAriseRouter.validateToken(params: token) { (error) in
                if(error != nil) {
                    print("Opened Arise SDK successfully")
                }else {
                    print("Failed to open Arise SDK")
                }
            }
        }
    }
    
    func ariseSeamlessLoginDidFail(_ error: NSError) {
        print(#function)
    }
    
    func ariseSeamlessLoginDidSucceed() {
        print(#function)
    }
    
    func onAriseHeartBeat() {
        print(#function)
    }
    
    func onUserLoginRequest(deeplink: String) {
        print(#function)
    }
    
    func onAriseAuthenticationError() {
        print(#function)
    }
    
    func onSessionExpired() {
        print(#function)
    }
    
    func isUserSessionValid() -> Bool {
        return AppState.shared.sessionValid
    }
    
    func onAriseSdkLoggedOut() {
        print("MIB Level onAriseSdkLoggedOut")
        print(#function)
    }
    
    func onAriseSDKExit(data:[String:String]) {
        print("SDK Exit Data: \(data)")
    }
    // Payment Gateway 
}

class Alerts {
    static func showActionsheet(viewController: UIViewController, title: String, message: String, actions: [(String, UIAlertAction.Style)],preferredStyle:UIAlertController.Style = .actionSheet, completion: @escaping (_ index: Int) -> Void) {
    let alertViewController = UIAlertController(title: title, message: message, preferredStyle: preferredStyle)
    for (index, (title, style)) in actions.enumerated() {
        let alertAction = UIAlertAction(title: title, style: style) { (_) in
            completion(index)
        }
        alertViewController.addAction(alertAction)
     }
     viewController.present(alertViewController, animated: true, completion: nil)
    }
}
