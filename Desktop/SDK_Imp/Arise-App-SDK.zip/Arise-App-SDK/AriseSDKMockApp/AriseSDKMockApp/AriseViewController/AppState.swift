//
//  AppState.swift
//  AriseMIB
//
//  Created by Lokesh Vyas on 29/07/21.
//

import Foundation
import UIKit

class AppState {
    
    static let shared = AppState.init()
    let defaults: UserDefaults = UserDefaults.standard
    
    static let environment = "environment"
    static let timeOut = "timeOut"
    static let language = "language"
    static let customerID = "customerID"
    static let sessionValid = "sessionValid"
    
    var environment: String {
        get {
            return defaults.string(forKey: AppState.environment) ?? ""
        }
        set {
            defaults.set(newValue, forKey: AppState.environment)
            defaults.synchronize()
        }
    }
    
    var timeOut: Double {
        get {
            return defaults.double(forKey: AppState.timeOut)
        }
        set {
            defaults.set(newValue, forKey: AppState.timeOut)
            defaults.synchronize()
        }
    }
    
    var language: String {
        get {
            return defaults.string(forKey: AppState.language) ?? ""
        }
        set {
            defaults.set(newValue, forKey: AppState.language)
            defaults.synchronize()
        }
    }
    
    var customerID: String {
        get {
            return defaults.string(forKey: AppState.customerID) ?? ""
        }
        set {
            defaults.set(newValue, forKey: AppState.customerID)
            defaults.synchronize()
        }
    }
    
    var sessionValid: Bool {
        get {
            return defaults.bool(forKey: AppState.sessionValid)
        }
        set {
            defaults.set(newValue, forKey: AppState.sessionValid)
            defaults.synchronize()
        }
    }
}

enum AppStoryboard: String {
    case main = "Main"

    var instance: UIStoryboard {
        return UIStoryboard(name: self.rawValue, bundle: Bundle.main)
    }

    func viewController<T: UIViewController>(viewControllerClass: T.Type) -> T {
        let storyboardID = (viewControllerClass as UIViewController.Type).storyboardID

        guard let scene = instance.instantiateViewController(withIdentifier: storyboardID) as? T else {
            fatalError("ViewController with identifier \(storyboardID), not found in \(self.rawValue) Storyboard.")
        }
        return scene
    }

    func initialViewController() -> UIViewController? {

        return instance.instantiateInitialViewController()
    }
}

extension UIViewController {
    // Not using static as it wont be possible to override to provide custom storyboardID then
    class var storyboardID: String {
        return "\(self)"
    }

    static func instantiate(fromAppStoryboard appStoryboard: AppStoryboard) -> Self {
        return appStoryboard.viewController(viewControllerClass: self)
    }
}
