//
//  SeamlessLogin.swift
//  AriseMIB
//
//  Created by Lokesh Vyas on 29/07/21.
//

import Foundation
import UIKit

enum AppEnvironment: String {
    case PRODUCTION
    case UAT
    case DEV
}

final class EnvironmentConfiguration {
    class func partnerKey() -> String {
        switch AppState.shared.environment {
          case "UAT":
            return "c964cc15-dedf-45d9-a948-1dac2b3446d1"
          case "PROD":
            return "c964cc15-dedf-45d9-a948-1dac2b3446d1"
          case "DEV":
            return "YAmVvaMXsZKeNFAxptSkQV"
          default:
            return "YAmVvaMXsZKeNFAxptSkQV"
        }
    }
}


class SeamlessLogin {
    var url: String
    
    init() {
        switch AppState.shared.environment {
        case "UAT":
            url = "https://arise-uat.gonuclei.com:443/api/iam-mock/v1/generateToken"
        case "PROD":
            url = "https://arise-uat.gonuclei.com:443/api/iam-mock/v1/generateToken"
        case "DEV":
            url = "https://arise-dev.gonuclei.com:443/api/iam-mock/v1/generateToken"
        default:
            url = "https://arise-uat.gonuclei.com:443/api/iam-mock/v1/generateToken"
        }
    }
    
    
    func generateToken(customerID:String,parameters:[String:String],onCompletion : @escaping ([String:String]) -> (),onFail : @escaping (String) -> ()){
        var params = parameters
        params["external_id"] = customerID
        print("generateToken::::-> Params \(params) .... URL \(self.url)")
        let apiUrl = URL(string: self.url)
        var urlRequest = URLRequest(url: apiUrl!)
        urlRequest.httpMethod = "POST"
        urlRequest.addValue("application/json", forHTTPHeaderField: "content-type")
        
        do {
            urlRequest.httpBody = try JSONSerialization.data(withJSONObject: params, options: .prettyPrinted)
        } catch let error {
            print(error.localizedDescription)
        }
        
        let session = URLSession.shared
    
        let task = session.dataTask(with: urlRequest) {
            (data, response, error) in
            DispatchQueue.main.async {
                if let httpResponse = response as? HTTPURLResponse {
                    if (200...299).contains(httpResponse.statusCode) {
                        if data != nil {
                            if let result = try? JSONSerialization.jsonObject(with: data!, options: [])
                                as? [String: String]  {
                                onCompletion(result)
                            }
                        }
                    }
                    else if (500...511).contains(httpResponse.statusCode) {
                        onFail("Internal server error")
                        print("Internal server error")
                    }
                    else {
                        onFail("Token Expired")
                        print("Token Expired")
                    }
                }
            }
        }
        task.resume()
    }
}
