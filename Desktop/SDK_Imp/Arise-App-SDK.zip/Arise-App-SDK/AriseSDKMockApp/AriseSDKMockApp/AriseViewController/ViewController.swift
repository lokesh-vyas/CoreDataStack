//
//  ViewController.swift
//  AriseMIB
//
//  Created by Lokesh Vyas on 08/07/21.
//

import UIKit


class ViewController: UIViewController {
    
    @IBOutlet weak var txtFieldCustomerID: UITextField!
    var tempToken : [String:String]?
    var targetLang = "en"
    var sessionValid = true
    var timeOutLimit = (300000.0,"5 min") // 5 min
    var isSDKLogout = false
    @IBOutlet weak var envName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if AppState.shared.customerID.count > 1 {
            let vc = AriseOpenViewController.instantiate(fromAppStoryboard: .main)
            self.navigationController?.pushViewController(vc, animated: true)
            return
        }
        self.envName.text = "UAT"
        AppState.shared.environment = "UAT"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.isSDKLogout = false
        self.txtFieldCustomerID.text = AppState.shared.customerID
        self.envName.text = AppState.shared.environment
    }
    
    @IBAction func openArise(_ sender: Any) {
        if (self.txtFieldCustomerID.text?.count ?? 0 > 0) {
            let vc = AriseOpenViewController.instantiate(fromAppStoryboard: .main)
            AppState.shared.language = self.targetLang
            AppState.shared.timeOut = self.timeOutLimit.0
            AppState.shared.customerID = self.txtFieldCustomerID.text ?? ""
            AppState.shared.sessionValid = sessionValid
            vc.isSDKLogout = self.isSDKLogout
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            var actions: [(String, UIAlertAction.Style)] = []
            actions.append(("OK", UIAlertAction.Style.cancel))
            
            Alerts.showActionsheet(viewController: self, title: "Please enter  Customer ID", message: "Enter correct customer id to use Arise",actions: actions, preferredStyle:.alert) { (index) in
            }
        }
    }
    
    
    @IBAction func timeOut(_ sender: Any) {
        self.view.endEditing(true)
        var actions: [(String, UIAlertAction.Style)] = []
        actions.append(("2 min", UIAlertAction.Style.default))
        actions.append(("5 min", UIAlertAction.Style.default))
        actions.append(("10 min", UIAlertAction.Style.default))
        actions.append(("DEFAULT", UIAlertAction.Style.cancel))
        
        Alerts.showActionsheet(viewController: self, title: "", message: "Please select time out limit.", actions: actions) { (index) in
            
            switch index {
            case 0:
                self.timeOutLimit = (120000.0,"2 min")
                break
            case 1:
                self.timeOutLimit = (300000.0,"5 min")
                break
            case 2:
                self.timeOutLimit = (600000.0,"10 min")
                break
            default:
                self.timeOutLimit = (300000.0,"5 min")
                break
            }
        }
    }
    
    func clearAllFile() {
        let documentsUrl =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!

        do {
            let fileURLs = try FileManager.default.contentsOfDirectory(at: documentsUrl,
                                                                       includingPropertiesForKeys: nil,
                                                                       options: .skipsHiddenFiles)
            for fileURL in fileURLs {
                try FileManager.default.removeItem(at: fileURL)
            }
        } catch  { print(error) }
    }
    
    @IBAction func changeEnv(_ sender: Any) {
        self.clearAllFile()
        FileManager.default.clearTmpDirectory()
        self.view.endEditing(true)
        var actions: [(String, UIAlertAction.Style)] = []
        actions.append(("DEV", UIAlertAction.Style.default))
        actions.append(("UAT", UIAlertAction.Style.default))
        actions.append(("PROD", UIAlertAction.Style.default))
        actions.append(("DEFAULT", UIAlertAction.Style.cancel))
        Alerts.showActionsheet(viewController: self, title: "", message: "Please select environment.", actions: actions) { (index) in
            switch index {
            case 0:
                self.isSDKLogout = true
                AppState.shared.environment = "DEV"
                self.envName.text = AppState.shared.environment
                break
            case 1:
                self.isSDKLogout = true
                AppState.shared.environment = "UAT"
                self.envName.text = AppState.shared.environment
                break
            case 2:
                self.isSDKLogout = true
                AppState.shared.environment = "PROD"
                self.envName.text = AppState.shared.environment
                break
            default:
                self.isSDKLogout = true
                AppState.shared.environment = "UAT"
                self.envName.text = AppState.shared.environment
                break
                
            }
        }
    }
    
    @IBAction func userSessionValid(_ sender: Any) {
        self.view.endEditing(true)
        var actions: [(String, UIAlertAction.Style)] = []
        actions.append(("True", UIAlertAction.Style.default))
        actions.append(("False", UIAlertAction.Style.default))
        actions.append(("Default", UIAlertAction.Style.cancel))
        
        Alerts.showActionsheet(viewController: self, title: "", message: "Do you want user seesion should be valid while App exceed time out or not.", actions: actions) { [self] (index) in
            if index == 1 {
                self.sessionValid = true
            } else {
                self.sessionValid = false
            }
        }
    }
    
    @IBAction func changeLang(_ sender: Any) {
        self.view.endEditing(true)
        var actions: [(String, UIAlertAction.Style)] = []
        actions.append(("English", UIAlertAction.Style.default))
        actions.append(("Arabic", UIAlertAction.Style.default))
        actions.append(("Default", UIAlertAction.Style.cancel))
        
        Alerts.showActionsheet(viewController: self, title: "", message: "Please select your language.", actions: actions) { (index) in
            if index == 1 {
                self.targetLang = "ar"
            } else {
                self.targetLang = "en"
            }
        }
    }
}

extension ViewController : UITextFieldDelegate
{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
}


extension FileManager {
    func clearTmpDirectory() {
        do {
            let tmpDirURL = FileManager.default.temporaryDirectory
            let tmpDirectory = try contentsOfDirectory(atPath: tmpDirURL.path)
            try tmpDirectory.forEach { file in
                let fileUrl = tmpDirURL.appendingPathComponent(file)
                try removeItem(atPath: fileUrl.path)
            }
        } catch {
           //catch the error somehow
        }
    }
}
