//
//  AppDelegate.swift
//  AriseSDKMockApp
//
//  Created by Lokesh Vyas on 04/08/21.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {


    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        // Override point for customization after application launch.
               window?.rootViewController = nil
               let storyboard = UIStoryboard(name: "Main", bundle: nil)
               window?.rootViewController = storyboard.instantiateInitialViewController()
               window?.makeKeyAndVisible()
        return true
    }

}

