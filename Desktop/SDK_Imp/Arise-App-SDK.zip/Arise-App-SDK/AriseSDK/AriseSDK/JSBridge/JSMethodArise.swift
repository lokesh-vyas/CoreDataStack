//
//  JSMethodArise.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 15/07/21.
//

import Foundation

class AriseConfigProperties {
    
    static let dsBridgeNamespace = "arise_native_sdk"
    
    static var didReceiveCallbackFromArise = true
    
}

class JavascriptChannelMethods: NSObject {
    
    //1. Flutter sdk load complete
    @objc func onAriseSdkLoadComplete(_ arg:String) {
        AriseLogger().LogD(value: "url loading completed")
    }
    
    //2. getPartnerApplicationData
    @objc func getPartnerApplicationDataSync(_ arg:String) -> String {
        return FlutterJSMethodCallHelper.init().sendPartnerApplicationData()
    }
    
    //3. From key we need to fetch value from Model
    @objc func getValueFromMemStorage(_ arg:String) -> String {
        let authToken = AriseMemStore.sharedInstance.getValue(key: arg)
        if authToken.count > 0 {
            return authToken
        }
        return ""
    }
    
    //4. Get Token From Bank (If 3 step doesn't have token)
    @objc func onSeamlessLoginRequest(_ arg:String) {
        DispatchQueue.main.async {
            AriseLogger().LogD(value: "seamless login request")
            if let seamlessRequest = ParentAppCommunicationHandler().initiateSeamlessRequest().dictionary {
                AriseConfiguration.sharedInstance.configDelegate?.onAriseSdkSeamlessLoginRequest(seamlessRequestData: seamlessRequest)
            }
        }
    }
    
    //5. On seamless login success
    @objc func onLoginSuccess(_ arg:String) {
        AriseLogger().LogD(value: "on Arise login success")
        DispatchQueue.main.async {
            AriseConfiguration.sharedInstance.configDelegate?.ariseSeamlessLoginDidSucceed()
        }
    }
    
    // 6.
    @objc func storeMapInMemStorage(_ arg:String) {
        DispatchQueue.main.async {
            if let data = arg.data(using: .utf8) {
                do{
                    let dictData = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String:String]
                    if let dictionaryData = dictData {
                        for (key, value) in dictionaryData {
                            AriseLogger().LogD(value: "\(key) : \(value)")
                            AriseMemStore.sharedInstance.putValue(key: key, value: value)
                        }
                    }
                }
                catch {
                    AriseLogger().LogI(value: error)
                }
            }
        }
    }
    
    //7. On Login Failure
    @objc func onLoginFailure(_ arg:String) {
        DispatchQueue.main.async {
            AriseConfiguration.sharedInstance.coordinator?.controlWebViewVisibility()
            AriseLogger().LogD(value: "on Arise login failed")
            AriseConfiguration.sharedInstance.configDelegate?.onAriseAuthenticationError()
        }
    }
    
    // 8. SDK Exit
    @objc func onAriseSdkExit( _ arg:String) {
        DispatchQueue.main.async {
            if arg == "" {
                AriseConfiguration.sharedInstance.coordinator?.exitArise(extraData: nil)
                return
            }
            if let data = arg.data(using: .utf8) {
                do{
                    let dictData = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String:String]
                    if (dictData != nil) {
                        AriseConfiguration.sharedInstance.coordinator?.exitArise(extraData: dictData)
                    } else {
                        AriseConfiguration.sharedInstance.coordinator?.exitArise(extraData: nil)
                    }
                }
                catch {
                    AriseLogger().LogI(value: "onAriseSdkExit: \(error)")
                    // AriseConfiguration.sharedInstance.coordinator?.exitArise(extraData: nil)
                }
            } else {
                AriseConfiguration.sharedInstance.coordinator?.exitArise(extraData: nil)
            }
        }
    }
    
    @objc func onAriseHeartBeat(_ arg:String) {
        DispatchQueue.main.async {
            IdleTimeOutManager.sharedInstance.onHeartBeat()
        }
    }
    
    @objc func loadHyperlink(_ arg:String) {
        DispatchQueue.main.async {
            AriseConfiguration.sharedInstance.coordinator?.loadHyperLink(url: arg)
        }
    }
    
    @objc func onHideNativeLoader(_ arg:String) {
        AriseLogger().LogD(value: "Hide Native Looder")
        DispatchQueue.main.async {
            AriseConfigProperties.didReceiveCallbackFromArise = true
            AriseConfiguration.sharedInstance.coordinator?.controlWebViewVisibility()
        }
    }
    
    @objc func onShowNativeLoader(_ arg:String) {
        AriseLogger().LogD(value: "show Native Looder")
        DispatchQueue.main.async {
            AriseConfiguration.sharedInstance.coordinator?.showNativeLodder()
        }
    }
    
    // From key we need to fetch value from Model
    @objc func removeValueFromMemStorage(_ arg:String) {
        DispatchQueue.main.async {
            AriseMemStore.sharedInstance.remove(key: arg)
        }
        // From key we need to remove value from Model
    }
    
    @objc func onAriseSdkLogout(_ arg:String) {
        AriseLogger().LogD(value: "Logout")
        DispatchQueue.main.async {
            LogoutHandler().Logout()
        }
    }
    
    
    // From key we need to clear Storage.
    @objc func clearNativeMemStorage(_ arg:String) {
        DispatchQueue.main.async {
            AriseMemStore.sharedInstance.clearAll()
        }
    }
    
    @objc func isNetworkAvailable(_ arg:String) -> String {
        let networkStatus = AriseConnectivity.isConnectedToInternet
        let status: String = String(networkStatus)
        return status
    }
    
    @objc func onAriseSdkLogoutInternal(_ arg:String) {
        AriseLogger().LogD(value: "Internal Logout")
        DispatchQueue.main.async {
            LogoutHandler().InternalLogout()
        }
    }
}
