//
//  AriseWebViewController.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 15/07/21.
//

import Foundation
import UIKit

let screenHeight = UIScreen.main.bounds.height
let screenWidth = UIScreen.main.bounds.width

class AriseWebViewController: UIViewController {
    
    var webView: DWKWebView!
    var addedObserver = false
    var backButton:UIButton?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUpWebView()
        self.setBackButton()
        AriseSVProgressHUD.show(currentViewController: self)
        self.fetchWebSDKUrl()
    }
    
    private func fetchWebSDKUrl() {
        self.backButton?.isUserInteractionEnabled = true
        self.view.bringSubviewToFront(self.backButton!)
        if AriseConnectivity.isConnectedToInternet {
            if let getAriseFASMConfig = AriseCoreSetup.sharedInstance.getAriseFASMConfig {
                FasmCore.sync(config:  getAriseFASMConfig, onCompletion: { (localUrl,webUrl,params) in
                    
                    // Local Url(path): it will give resultant Local Directory URL
                    // WebUrl :- Resultant web url which is used to load web page
                    // params :- Dictionary type for whitelist URL's
                    DispatchQueue.main.async {
                        AriseCoreSetup.sharedInstance.getAriseSDKUrl = webUrl ?? ""
                        AriseCoreSetup.sharedInstance.getAriseSDKDirectory = localUrl
                        self.loadWebViewUrl()
                    }
                }, onError: { (error) in
                    AriseLogger().LogI(value: error)
                    AriseCoreSetup.sharedInstance.getAriseFASMConfig = nil
                    self.showNoInternetView(msgString: "ar_some_thing_went_wrong_message".coreLocalized)
                })
            } else {
                NucleiWebZip().setZipAapterConfig()
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                    self.fetchWebSDKUrl()
                })
            }
        } else {
            self.showNoInternetView()
        }
        
    }
    
    private func  setUpWebView() {
        let configuration = WKWebViewConfiguration()
        configuration.setURLSchemeHandler(CustomeSchemeHandler(), forURLScheme: "custom-scheme")
        webView = DWKWebView(frame: .zero, configuration: configuration)
        if AriseCoreSetup.sharedInstance.getAriseSDKLogsEnable == "1" {
            let source = "function captureLog(msg) { window.webkit.messageHandlers.logHandler.postMessage(msg); } window.console.log = captureLog;"
            let script = WKUserScript(source: source, injectionTime: .atDocumentEnd, forMainFrameOnly: false)
            webView?.configuration.userContentController.addUserScript(script)
            webView?.configuration.userContentController.add(self, name: "logHandler")
        }
        
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(webView)
        webView?.isHidden = false
        self.webView?.scrollView.contentInsetAdjustmentBehavior = .never
        let topSafeArea = UIApplication.shared.windows.first?.rootViewController?.view.safeAreaInsets.top ?? 20
        webView?.frame = CGRect(x: 0, y: topSafeArea, width: screenWidth, height: screenHeight - topSafeArea)
        
        self.addedObserver = true
        webView?.addObserver(self, forKeyPath: #keyPath(WKWebView.estimatedProgress), options: .new, context: nil)
        
        self.webView?.addJavascriptObject(JavascriptChannelMethods(),
                                          namespace: AriseConfigProperties.dsBridgeNamespace)
        
        self.webView?.navigationDelegate = self
        self.webView?.dsuiDelegate = self
        self.webView?.scrollView.showsHorizontalScrollIndicator = false
        self.webView.scrollView.isScrollEnabled = false
        
        self.webView?.scrollView.showsVerticalScrollIndicator = false
        self.webView?.scrollView.bounces = false
    }
    
    private func loadWebViewUrl() {
        if(AriseConnectivity.isConnectedToInternet) {
            
            if let urlString =  customWebURL() {
                var request = URLRequest(url: urlString)
               // request.cachePolicy = .reloadIgnoringCacheData
                self.webView?.isHidden = true
                self.webView?.load(request)
                
                self.waitUntilFullyLoaded { [weak self] in
                    guard self != nil else { return }
                }
            }
        } else {
            self.showNoInternetView()
        }
        IdleTimeOutManager.sharedInstance.startTimer()
    }
    
    // Load Web View
    override func loadView() {
        self.view = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight))
    }
    
    deinit {
        AriseLogger().LogD(value: "dealloc")
    }
    
    // Set Back Button
    private func setBackButton() {
        self.backButton?.isHidden = false
        if AriseCoreSetup.sharedInstance.preferredLocalization == .arabic {
            self.backButton = UIButton(frame: CGRect(x: self.view.frame.maxX - 38, y: Utill().safeAreaTopPadding() + 18, width: 30, height: 20))
            self.backButton?.semanticContentAttribute = .forceRightToLeft
            self.backButton?.setImage(UIImage(named: "BackNew")?.imageFlippedForRightToLeftLayoutDirection(), for: .normal)
        } else {
            self.backButton = UIButton(frame: CGRect(x: 9, y: Utill().safeAreaTopPadding() + 18, width: 30, height: 20))
            self.backButton?.setImage(UIImage(named: "BackNew"), for: .normal)
        }
        
        self.backButton?.imageView?.contentMode = .scaleAspectFit
        self.backButton?.addTarget(self, action:#selector(self.handleBackPress), for: .touchUpInside)
        self.view.addSubview(self.backButton ?? UIButton())
    }
    
    func deinitWebView(){
        self.webView?.removeJavascriptObject(AriseConfigProperties.dsBridgeNamespace)
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "logHandler")
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        if self.addedObserver {
            self.addedObserver = false
            webView?.removeObserver(self, forKeyPath: #keyPath(WKWebView.estimatedProgress))
        }
        IdleTimeOutManager.sharedInstance.cancelTimer()
        AriseConfigProperties.didReceiveCallbackFromArise = false
        
        self.webView?.removeFromSuperview()
        self.webView = nil
        self.backButton = nil
    }
    
    func waitUntilFullyLoaded(_ completionHandler: @escaping () -> Void) {
        if webView == nil {
            self.webView?.removeFromSuperview()
            return
        }
        if AriseConnectivity.isConnectedToInternet {
            if (self.webView.estimatedProgress >= 1.0 && AriseConfigProperties.didReceiveCallbackFromArise){
                AriseLogger().LogI(value: "Webview fully loaded!")
                completionHandler()
            } else {
                AriseLogger().LogI(value: "Webview not fully loaded yet....")
                DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: {
                    [weak self] in
                    self?.waitUntilFullyLoaded(completionHandler)
                })
            }
        } else {
            self.showNoInternetView()
        }
    }
}

extension AriseWebViewController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        AriseLogger().LogD(value: #function)
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        AriseLogger().LogD(value: #function)
        self.webView.stopLoading()
        AriseLogger().LogD(value: "Webview Load Fail...")
        AriseSVProgressHUD.dismiss(currentViewController: self)
        self.showNoInternetView(msgString: "ar_some_thing_went_wrong_message".coreLocalized)
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let host = navigationAction.request.url?.host {
            let urlHost = URL(string: AriseCoreSetup.sharedInstance.getAriseSDKUrl)?.host ?? ""
            if host.contains(urlHost) {
                decisionHandler(.allow)
                return
            }
        }
        decisionHandler(.cancel)
        self.webView.stopLoading()
        AriseLogger().LogD(value: "Webview Load Fail...")
        AriseSVProgressHUD.dismiss(currentViewController: self)
        self.showNoInternetView(msgString: "ar_some_thing_went_wrong_message".coreLocalized)
    }
    
    func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {
        scrollView.pinchGestureRecognizer?.isEnabled = false
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "estimatedProgress" {
            AriseLogger().LogI(value: webView?.estimatedProgress ?? "")
        }
    }
}

extension AriseWebViewController: WKScriptMessageHandler {
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "logHandler" {
            AriseLogger().LogI(value: "Console LOG: \(message.body)")
        }
    }
}
extension AriseWebViewController: StateCoordinator {
    func isLoaded() -> Bool {
        return self.view.window != nil
    }
}

extension AriseWebViewController: MainCoordinator {
    func goTo(route: Route, completion: @escaping (_ error: Error?) -> Void) {
        switch route {
        case .Open:
            if ((AriseConfiguration.sharedInstance
                    .configDelegate?.isPartnerApplicationLoggedIn())! && !isLoaded()) {
                self.hidesBottomBarWhenPushed = true
                self.modalPresentationStyle = .overFullScreen
                UIViewController.topMost?.present(self, animated: false, completion: nil)
            }
        case .Close:
            self.exitArise(extraData: nil)
            break
            
        case .ValidateToken(let params):
            if let token = params[Constants.PROVISIONAL_TOKEN_KEY] {
                self.sendProvisonTokenData(token: token)
            }
            break
            
        case .Authenticate(_):
            // self.sendMpinStatus(mpinStatus: status)
            break
            
        case .FetchProvisionalTokenFailed(let errorString):
            self.fetchProvisonTokenFailed(error: errorString)
            break
        case .Logout:
            LogoutHandler().Logout()
            break
        }
    }
}

extension AriseWebViewController: WKUIDelegate {
    
    func loadHyperLink(url: String) {
        if let url = URL(string: url) {
            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
            }
        }
    }
    
    //    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
    //           let controller = UIAlertController.init(title: message, message: message, preferredStyle: .alert)
    //            controller.addAction(UIAlertAction(title: "Ok", style: .default) { (action:UIAlertAction!) in
    //                controller.dismiss(animated: true, completion: nil)
    //                    })
    //            self.present(controller, animated: true, completion: nil)
    //            return completionHandler();
    //    }
}
