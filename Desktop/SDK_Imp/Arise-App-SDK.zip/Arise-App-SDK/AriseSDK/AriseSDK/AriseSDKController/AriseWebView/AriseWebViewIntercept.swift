//
//  AriseWebViewIntercept.swift
//  AriseWebViewIntercept
//
//  Created by Lokesh Vyas on 30/09/21.
//

import Foundation
import UIKit
import WebKit

extension AriseWebViewController {
    
    func customWebURL() -> URL? {
        guard let url = URL(string: AriseCoreSetup.sharedInstance.getAriseSDKUrl) else { return nil }
        let components = NSURLComponents.init(url: url, resolvingAgainstBaseURL: true)!
        components.scheme = "custom-scheme"
        return components.url!
    }
}
class CustomeSchemeHandler : NSObject,WKURLSchemeHandler {
    
    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        DispatchQueue.global().async  {
            if let url = urlSchemeTask.request.url, url.scheme == "custom-scheme" {
                
                let path = url.path
                AriseLogger().LogD(value: path)
                AriseLogger().LogD(value: AriseCoreSetup.sharedInstance.getAriseSDKDirectory)
                if self.isLocalDirectoryCopyExists(for: path) {
                    AriseLogger().LogD(value: "local directory read \(url)")
                    let url = self.getLocalDirectoryURL(for: url.path)
                    let request = URLRequest(url: url)
                    
                    self.createRequest(request: request) { (data, response, error) in
                        var headers = self.customHeader()
                        headers["Content-Type"] = response?.mimeType
                        let httpResponse = HTTPURLResponse(url: urlSchemeTask.request.url!, statusCode: 200, httpVersion: "HTTPS/2.0", headerFields: headers)
                        
                        urlSchemeTask.didReceive(httpResponse!)
                        urlSchemeTask.didReceive(data ?? Data())
                        urlSchemeTask.didFinish()
                    }
                }
                else {
                    
                    let filename = url.lastPathComponent
                    
                    if self.isLocalBundleCopyExists(for: filename) {
                        AriseLogger().LogD(value: "local Bundle read \(url)")
                        let url = self.getLocalBundleURL(for: filename)
                        let request = URLRequest(url: url)
                        
                        self.createRequest(request: request) { (data, response, error) in
                            var headers = self.customHeader()
                            headers["Content-Type"] = response?.mimeType
                            let httpResponse = HTTPURLResponse(url: urlSchemeTask.request.url!, statusCode: 200, httpVersion: "HTTP/2.0", headerFields: headers)
                            urlSchemeTask.didReceive(httpResponse!)
                            urlSchemeTask.didReceive(data ?? Data())
                            urlSchemeTask.didFinish()
                        }
                    }
                    else {
                        // modify scheme and hit remote url
                        let components = NSURLComponents.init(url: urlSchemeTask.request.url!, resolvingAgainstBaseURL: true)!
                        components.scheme = "https"
                        AriseLogger().LogD(value: "Read from server - \(components.url!)")
                        let request = URLRequest(url: components.url!)
                        self.createRequest(request: request) { (data, response, error) in
                            var headers = self.customHeader()
                            headers["Content-Type"] = response?.mimeType
                            let httpResponse = HTTPURLResponse(url: urlSchemeTask.request.url!, statusCode: 200, httpVersion: "HTTP/2.0", headerFields: headers)
                            
                            urlSchemeTask.didReceive(httpResponse!)
                            urlSchemeTask.didReceive(data ?? Data())
                            urlSchemeTask.didFinish()
                        }
                        
                    }
                }
            }
        }
    }
    
    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {
        
    }
    
    func customHeader() -> [String: String] {
        let headers = [
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods": "GET, OPTIONS",
            // "Access-Control-Max-Age": "333333333",
            "Access-Control-Allow-Credentials": "true",
            "Access-Control-Allow-Headers": "*",
            // "Age": "9994853",
            // "Cache-Control": "public, max-age=31536000",
            // "Etag": "W/\"689192-5D3C7YqB62gpVVLrMsFA8igFO0g\"",
            // "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
        ]
        return headers
    }
    
    private lazy var session: URLSession = {
        // Create URL Session Configuration
        let configuration = URLSessionConfiguration.default
        
        // Define Request Cache Policy
        configuration.requestCachePolicy = .useProtocolCachePolicy
        
        return URLSession(configuration: configuration)
        
    }()
    
    func getLocalDirectoryURL(for resource: String) -> URL {
        let localURL = self.localWebRootContainer(webUrl: resource)
        return localURL
    }
    
    func isLocalDirectoryCopyExists(for resource: String) -> Bool {
        let fileManager = FileManager.default
        let localURL = self.localWebRootContainer(webUrl: resource)
        return fileManager.fileExists(atPath: localURL.path)
    }
    
    
    func getLocalBundleURL(for resource: String) -> URL {
        let path = AriseStoryBoardHandler().bundle?.path(forResource: resource, ofType: nil)
        return URL(fileURLWithPath: path!, isDirectory: false)
    }
    
    func isLocalBundleCopyExists(for resource: String) -> Bool {
        return (AriseStoryBoardHandler().bundle?.path(forResource: resource, ofType: nil) != nil)
    }
    
    private func createRequest(request: URLRequest, completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) {
        let task = session.dataTask(with: request) { (data, response, error) in
            completionHandler(data,response,error)
        }
        task.resume()
    }
    
    func localWebRootContainer(webUrl: String) -> URL {
        let directoryPath = AriseCoreSetup.sharedInstance.getAriseSDKDirectory
        let url = URL(fileURLWithPath:directoryPath).appendingPathComponent(webUrl)
        
        return url
        
    }
    
}

extension String {
    
    func fileName() -> String {
        return NSURL(fileURLWithPath: self).deletingPathExtension?.lastPathComponent ?? ""
    }
}
