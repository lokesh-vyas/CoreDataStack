//
//  AriseWebViewJSCallBack.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 09/12/21.
//

import Foundation

extension AriseWebViewController {
    
    func controlWebViewVisibility() {
        AriseSVProgressHUD.dismiss(currentViewController: self)
        self.webView?.isHidden = false
        self.backButton?.isHidden = true
    }
    // Show Native Lodder
    @objc func showNativeLodder() {
        AriseSVProgressHUD.show(currentViewController: self)
    }
    // Hide Native Lodder
    @objc func hideNativeLodder() {
        AriseSVProgressHUD.dismiss(currentViewController: self)
    }
    
    // Show No Internet
    @objc func showNoInternetView(msgString : String? = nil){
        let noview = NoInternetErrorView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight))
        if let _msgString = msgString {
            noview.setUpUI(msgString: _msgString)
        } else {
            noview.setUpUI(msgString:"internet_failure_msg".coreLocalized)
        }
        self.backButton?.isHidden = true
        noview.closeAction = { [] in
            AriseLogger().LogD(value: "Close Action")
            self.exitArise(extraData: nil)
        }
        noview.retryAction = { [] in
            AriseLogger().LogD(value: "Retry Action")
            self.backButton?.isHidden = false
            self.reInitArise()
        }
        self.view = noview
    }
    
    @objc func reInitArise() {
        AriseConfigProperties.didReceiveCallbackFromArise = false
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        if AriseConnectivity.isConnectedToInternet {
            UIView.animate(withDuration: 1.0, delay: 1.2, options: .curveEaseOut, animations: {
                self.deinitWebView()
                self.view = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight))
            }, completion: { finished in
                self.viewDidLoad()
            })
        } else {
            self.hideNativeLodder()
        }
    }
    
    // Alert Pop Up
    @objc func showAlertPopUp() {
        if(AriseConnectivity.isConnectedToInternet) {
            let vc: ArisePopUpViewController = AriseStoryBoardHandler().storyboard.instantiateViewController(withIdentifier: "ArisePopUpViewController") as! ArisePopUpViewController
            vc.modalPresentationStyle = .overFullScreen
            vc.alertPopupData = AlertPopupData(title: "Information".coreLocalized, body: "time_exceeded_msg".coreLocalized, primaryCtaData: CTAData(label: "Ok".coreLocalized), secondaryCtaData: nil, isBackPressDisable: nil, isTouchOutSideDisable: nil, alertCtaCallback: nil)
            
            self.present(vc, animated: true, completion: nil)
        } else {
            self.showNoInternetView()
        }
        
    }
    
    
    @objc func exitArise(extraData:[String:String]?) {
        DispatchQueue.main.async {
            if let _extraData = extraData {
                AriseConfiguration.sharedInstance.configDelegate?.onAriseSDKExit(data: _extraData)
            } else {
                let defaultDataMap = ["NAVIGATION":"HOME"]
                AriseConfiguration.sharedInstance.configDelegate?.onAriseSDKExit(data: defaultDataMap)
            }
            self.closeArise()
        }
    }
    
    @objc func closeArise() {
        self.deinitWebView()
        AriseConfiguration.sharedInstance.dispose()
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func handleBackPress() {
        AriseLogger().LogD(value: "Arise Exit : back press")
        LogoutHandler().InternalLogout()
        self.exitArise(extraData: nil)
    }
}

