//
//  AriseConfiguration.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 15/07/21.
//

import Foundation



class AriseConfiguration {
    
    var coordinator: AriseWebViewController?
    
    struct Static
    {
        static var instance: AriseConfiguration?
    }

    class var sharedInstance: AriseConfiguration
    {
        if Static.instance == nil
        {
            Static.instance = AriseConfiguration()
        }

        AriseConfiguration.Static.instance?.coordinator = AriseConfiguration.Static.instance?.coordinator ?? AriseWebViewController()
        return Static.instance!
    }
    
    init() {}
   
    func dispose()
    {
        // should be called, during SDK dismiss
        AriseConfiguration.Static.instance?.coordinator = nil
    }
    
    weak var configDelegate: NucleiArisePartnerConfig?
    
    func processDeeplink(deeplink: Route,completion: @escaping (_ error: Error?) -> Void)  {
         coordinator?.goTo(route: deeplink, completion: completion)
    }
}
