//
//  MainCordinate.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 15/07/21.
//

import Foundation
import UIKit


enum Route {
    case Open
    case ValidateToken([String:String])
    case Close
    case Authenticate(String)
    case FetchProvisionalTokenFailed(String)
    case Logout
}

protocol MainCoordinator {
    func goTo(route: Route,completion: @escaping (_ error: Error?) -> Void)
}

protocol StateCoordinator {
    func isLoaded() -> Bool // view is visible/ already on stack
}
