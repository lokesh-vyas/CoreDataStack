//
//  AriseRouter.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 15/07/21.
//

import Foundation
import UIKit
/**
 * Partner app communicates with our wrapper using this class
 */
@objc public final class NucleiAriseSdkConfig: NSObject {
    
    @discardableResult
    public func configSetup(with config: NucleiArisePartnerConfig) -> NucleiAriseSdkConfig {
        AriseConfiguration.sharedInstance.configDelegate = config
        return self
    }
    
    @discardableResult
    public func setKey(_ partnerKey: String) -> NucleiAriseSdkConfig  {
        AriseCoreSetup.sharedInstance.partnerKey = partnerKey
        return self
    }
    
    @discardableResult
    public func setEnvironment(_ environment: AriseEnvironment) -> NucleiAriseSdkConfig  {
        AriseCoreSetup.sharedInstance.setAriseSDKUrl = ""
        AriseCoreSetup.sharedInstance.getEnvironment = environment.rawValue
        NucleiWebZip().setZipAapterConfig()
        return self
    }
    
    @discardableResult
    public func setDeviceId(_ deviceId: String) -> NucleiAriseSdkConfig {
        AriseCoreSetup.sharedInstance.getDeviceID = deviceId
        return self
    }
    
    @discardableResult
    public func setFcmToken(_ fcmToken: String) -> NucleiAriseSdkConfig  {
        AriseCoreSetup.sharedInstance.getFCMToken = fcmToken
        return self
    }
    
    @discardableResult
    public func enableLogs(_ showLogs: Bool) -> NucleiAriseSdkConfig  {
        AriseCoreSetup.sharedInstance.getAriseSDKLogsEnable = showLogs == true ? "1" :"0"
        return self
    }
    
    @discardableResult
    public func setAriseSdkUrl(_ sdkUrl: String) -> NucleiAriseSdkConfig  {
        AriseCoreSetup.sharedInstance.setAriseSDKUrl = sdkUrl
        NucleiWebZip().setZipAapterConfig()
        return self
    }
    
    @discardableResult
    public func setLanguage(_ langauge: String) -> NucleiAriseSdkConfig  {
        AriseCoreSetup.sharedInstance.preferredLocalization = PreferredLocalization(rawValue: langauge) ?? .english
        return self
    }
    
    @discardableResult
    public func setAdditionalData(_ additionalData: [String:String]) -> NucleiAriseSdkConfig  {
        AriseCoreSetup.sharedInstance.additionalData = additionalData
        return self
    }
    
    @discardableResult
    public func setIdlePopupTimer(_ popUpTriggerTimeInSec: Double, _ maxSessionTimeOutTimeInSec : Double) -> NucleiAriseSdkConfig {
        AriseCoreSetup.sharedInstance.getPopUpTriggerTimeInSec = popUpTriggerTimeInSec / 1000
        AriseCoreSetup.sharedInstance.getMaxSessionTimeOutTimeInSec = maxSessionTimeOutTimeInSec / 1000
        return self
    }
    
    public override init() {
    }
}

@objc public final class NucleiAriseRouter: NSObject {
    
    public static func validateToken(params: [String:String], completion: @escaping (_ error: Error?) -> Void)  {
        DispatchQueue.main.async {
            AriseConfiguration.sharedInstance.processDeeplink(deeplink: Route.ValidateToken(params), completion: completion)
        }
    }
    
    public static func open(completion: @escaping (_ error: Error?) -> Void)  {
        
        DispatchQueue.main.async {
            AriseConfiguration.sharedInstance.processDeeplink(deeplink: Route.Open, completion: completion)
        }
    }
    
    public static func close(completion: @escaping (_ error: Error?) -> Void)   {
        DispatchQueue.main.async {
            AriseConfiguration.sharedInstance.processDeeplink(deeplink: Route.Close, completion: completion)
        }
    }
    
    static func authenticateComplete(status: String, completion: @escaping (_ error: Error?) -> Void) {
        DispatchQueue.main.async {
            AriseConfiguration.sharedInstance.processDeeplink(deeplink: Route.Authenticate(status), completion: completion)
        }
    }
    
    public static func fetchProvisionalTokenFailed(errorMessage: String) {
        DispatchQueue.main.async {
            AriseConfiguration.sharedInstance.processDeeplink(deeplink: Route.FetchProvisionalTokenFailed(errorMessage), completion: {_ in })
        }
    }
    
    public static func doSDKLogout() {
        DispatchQueue.main.async {
            AriseConfiguration.sharedInstance.processDeeplink(deeplink: Route.Logout, completion: {_ in })
        }
    }
}



