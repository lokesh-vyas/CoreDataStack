//
//  NucleiWebZip.swift
//  NucleiWebZip
//
//  Created by Lokesh Vyas on 29/09/21.
//

import Foundation


class NucleiWebZip {
    
    let defaults: UserDefaults = UserDefaults.standard
    
    static let CacheName: String = "AriseSDK"
    // Constant var for ZIP SDK
    static let endPointURL : String = "ariseweb/config/config.json"
    
    static var BaseURL : String {
        switch AriseCoreSetup.sharedInstance.getEnvironment.lowercased() {
        case AriseEnvironment.UAT.rawValue:
            return "https://arise-preprod-sdk.gonuclei.com/"
        case AriseEnvironment.PRODUCTION.rawValue:
            return "https://arise-sdk.gonuclei.com/"
        default:
            return ""
        }
    }
    
    init() {}
    // To get ZIP Config
    
    func setZipAapterConfig() {
        
        if AriseCoreSetup.sharedInstance.setAriseSDKUrl == "" || AriseCoreSetup.sharedInstance.setAriseSDKUrl.isEmpty  {
            let configURL = NucleiWebZip.BaseURL + NucleiWebZip.endPointURL
            let zipConfig = FasmAapterConfig.setupWith(cacheName: NucleiWebZip.CacheName, configURL: configURL, hostVersion: AriseDeviceDetail.sdkVersion(), pinningKeyList: nil)
            AriseCoreSetup.sharedInstance.getAriseFASMConfig = zipConfig
        } else {
            let configURL = AriseCoreSetup.sharedInstance.setAriseSDKUrl + NucleiWebZip.endPointURL
            let zipConfig = FasmAapterConfig.setupWith(cacheName: NucleiWebZip.CacheName, configURL: configURL, hostVersion: AriseDeviceDetail.sdkVersion(), pinningKeyList: nil)
            AriseCoreSetup.sharedInstance.getAriseFASMConfig = zipConfig
        }
    }
}

