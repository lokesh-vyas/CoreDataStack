//
//  ZipCoreConfig.swift
//  Zip
//
//  Created by Prasanna on 22/09/21.
//

import Foundation
import UIKit

public struct FasmConfig {
    var cacheName: String?
    var configURL: String?
    var hostVersion: String?
    var pinningKeyList: [String]?
    init(cacheName: String, configURL: String, hostVersion: String, pinningKeyList: [String]?) {
        self.cacheName = cacheName
        self.configURL = configURL
        self.hostVersion = hostVersion
        self.pinningKeyList = pinningKeyList
    }
}

@objc public final class FasmAapterConfig: NSObject {
    
    public static func setupWith(cacheName: String, configURL: String, hostVersion: String, pinningKeyList: [String]?) -> FasmConfig {
        let config = FasmConfig(cacheName: cacheName, configURL: configURL, hostVersion: hostVersion, pinningKeyList: pinningKeyList)
        FasmCore.sync(config: config, onCompletion: {_,_,_ in}, onError: {_ in})
        return config
    }
}
