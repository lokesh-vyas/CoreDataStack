//
//  ZipDownloadManager.swift
//  Zip
//
//  Created by Prasanna on 22/09/21.
//

import Foundation
import UIKit
import CommonCrypto

final class DownloadUtility: NSObject {
    
    private var session: URLSession!
    private var ongoingDownloads: [String : FasmDownloadObject] = [:]
    private var backgroundSession: URLSession!
    private var pinningHostBlock: [String: [String]] = [:]
    
    private let rsa2048Asn1Header:[UInt8] = [
        0x30, 0x82, 0x01, 0x22, 0x30, 0x0d, 0x06, 0x09, 0x2a, 0x86, 0x48, 0x86,
        0xf7, 0x0d, 0x01, 0x01, 0x01, 0x05, 0x00, 0x03, 0x82, 0x01, 0x0f, 0x00
    ]
    
    var backgroundCompletionHandler: BackgroundDownloadCompletionHandler?
    
    static let shared: DownloadUtility = {return DownloadUtility()}()
    
    func download(request: URLRequest,
                  shouldDownloadInBackground: Bool = false,
                  onProgress progressBlock:DownloadProgressBlock? = nil,
                  onPinningRequest pinningRequest: @escaping PinningBlock,
                  onCompletion completionBlock:@escaping DownloadCompletionBlock) -> String? {
        
        
        guard let url = request.url else {
            completionBlock(EmptyURLError, nil,nil)
            return nil
        }
        
        guard let host = url.host else {
            completionBlock(EmptyURLError, nil,nil)
            return nil
        }
        
        pinningHostBlock[host] = pinningRequest()
        
        guard FasmConnectivity.isConnectedToInternet else {
            completionBlock(NoInternetError, nil,nil)
            return nil
        }
        
        if let _ = self.ongoingDownloads[url.absoluteString] {
            cancelDownload(forKey: url.absoluteString)
        }
        
        var downloadTask: URLSessionDownloadTask
        if shouldDownloadInBackground {
            downloadTask = self.backgroundSession.downloadTask(with: request)
        } else{
            downloadTask = self.session.downloadTask(with: request)
        }
        
        let download = FasmDownloadObject(downloadTask: downloadTask, progressBlock: progressBlock, completionBlock: completionBlock)
        
        let key = self.getDownloadKey(withUrl: url)
        self.ongoingDownloads[key] = download
        FasmNetworkLogger.logHTTPRequest(request, .request)
        downloadTask.resume()
        return key;
    }
    
    func downloadConfig(request: URLRequest,
                  onProgress progressBlock:DownloadProgressBlock? = nil,
                  onPinningRequest pinningRequest: @escaping PinningBlock,
                  onCompletion completionBlock:@escaping DownloadCompletionBlock)  {
        
        guard let url = request.url else {
            completionBlock(EmptyURLError, nil,nil)
            return
        }
        
        guard let host = url.host else {
            completionBlock(EmptyURLError, nil,nil)
            return
        }
        
        pinningHostBlock[host] = pinningRequest()
        
        guard FasmConnectivity.isConnectedToInternet else {
            completionBlock(NoInternetError, nil,nil)
            return
        }
        
        if let _ = self.ongoingDownloads[url.absoluteString] {
            cancelDownload(forKey: url.absoluteString)
        }
        
        self.createRequest(request: request) { (data, response, error) in
            do {
                if let data = data {
                    if let jsonData = try? JSONDecoder().decode(FASMConfigData.self, from: data) {
                        completionBlock(nil, nil, jsonData)
                    } else {
                        completionBlock(ConfigFetchError, nil, nil)
                    }
                } else {
                    completionBlock(ConfigFetchError, nil, nil)
                }
            }
        }
    }
    
    private func createRequest(request: URLRequest, completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) {
        let task = session.dataTask(with: request) { (data, response, error) in
            completionHandler(data,response,error)
        }
        task.resume()
    }
    
    func getDownloadKey(withUrl url: URL) -> String {
        return url.absoluteString
    }
    
    func currentDownloads() -> [String] {
        return Array(self.ongoingDownloads.keys)
    }
    
    func cancelAllDownloads() {
        for (_, download) in self.ongoingDownloads {
            let downloadTask = download.downloadTask
            downloadTask.cancel()
        }
        self.ongoingDownloads.removeAll()
    }
    
    func cancelDownload(forKey key:String?) {
        let downloadStatus = self.downloadInProgress(forKey: key)
        let presence = downloadStatus.status
        if presence {
            if let download = downloadStatus.downlod {
                download.downloadTask.cancel()
                self.ongoingDownloads.removeValue(forKey: key!)
            }
        }
    }
    
    func pause(forKey key:String?) {
        let downloadStatus = self.downloadInProgress(forKey: key)
        let presence = downloadStatus.status
        if presence {
            if let download = downloadStatus.downlod {
                let downloadTask = download.downloadTask
                downloadTask.suspend()
            }}
    }
    
    func resume(forUniqueKey key:String?) {
        let downloadStatus = self.downloadInProgress(forKey: key)
        let presence = downloadStatus.status
        if presence {
            if let download = downloadStatus.downlod {
                let downloadTask = download.downloadTask
                downloadTask.resume()
            }}
    }
    
    func isDownloadInProgress(forKey key:String?) -> Bool {
        let downloadStatus = self.downloadInProgress(forKey: key)
        return downloadStatus.status
        
    }
    
    private override init() {
        super.init()
        let sessionConfiguration = URLSessionConfiguration.default
        sessionConfiguration.requestCachePolicy = .useProtocolCachePolicy
        self.session = URLSession(configuration: sessionConfiguration, delegate: self, delegateQueue: nil)

        let bundleIdentifier = "com.gonuclei.zip"
        let backgroundConfiguration = URLSessionConfiguration.background(withIdentifier: bundleIdentifier)
        self.backgroundSession = URLSession(configuration: backgroundConfiguration, delegate: self, delegateQueue: OperationQueue())
    }
    
    private func downloadInProgress(forKey key:String?) -> (status: Bool, downlod: FasmDownloadObject?) {
        guard let key = key else { return (false, nil) }
        for (uniqueKey, download) in self.ongoingDownloads {
            if key == uniqueKey {
                return (true, download)
            }
        }
        return (false, nil)
    }
    
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        
        let host = challenge.protectionSpace.host
        let pinningKeys = pinningHostBlock[host]
        
        guard let publicKeys = pinningKeys else {
            // no keys passed i.e nil. Allow to continue
            completionHandler(.useCredential, nil)
            return
        }
        
        if (challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust) {
            
            if let serverTrust = challenge.protectionSpace.serverTrust {
                
                var secresult = SecTrustResultType.invalid
                let status = SecTrustEvaluate(serverTrust, &secresult)
                
                if(errSecSuccess == status) {
                    
                    var pinningSucceeded = false
                    let certificateCount = SecTrustGetCertificateCount(serverTrust)
                    for i in 0..<certificateCount {
                        
                        if let serverCertificate = SecTrustGetCertificateAtIndex(serverTrust, i) {
                            
                            // Public key pinning
                            if #available(iOS 10.3, *) {
                                let serverPublicKey = SecCertificateCopyPublicKey(serverCertificate)
                                let serverPublicKeyData: NSData = SecKeyCopyExternalRepresentation(serverPublicKey!, nil )!
                                let keyHash = sha256(data: serverPublicKeyData as Data)
                                let publicKeyHashes = publicKeys
                                
                                if publicKeyHashes.contains(keyHash) {
                                    pinningSucceeded = true
                                    break
                                }
                                
                            }
                        }
                        
                    }
                    
                    // check for the status of pinning comparision
                    if pinningSucceeded == true {
                        completionHandler(.useCredential, URLCredential(trust:serverTrust))
                        return
                    } else {
                        // Pinning failed
                        completionHandler(.cancelAuthenticationChallenge, nil)
                        return
                    }
                    
                }
            }
        }
        
        // Pinning failed
        completionHandler(.cancelAuthenticationChallenge, nil)
    }
    
    private func sha256(data : Data) -> String {
        var keyWithHeader = Data(bytes: rsa2048Asn1Header)
        keyWithHeader.append(data)
        var hash = [UInt8](repeating: 0,  count: Int(CC_SHA256_DIGEST_LENGTH))
        
        keyWithHeader.withUnsafeBytes {
            _ = CC_SHA256($0, CC_LONG(keyWithHeader.count), &hash)
        }
        return Data(hash).base64EncodedString()
    }
}

extension DownloadUtility: URLSessionDownloadDelegate {
    
    func urlSession(_ session: URLSession,
                    downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        
        let key = (downloadTask.originalRequest?.url?.absoluteString)!
        if let download = self.ongoingDownloads[key]  {
            if let response = downloadTask.response {
                let statusCode = (response as! HTTPURLResponse).statusCode
                FasmNetworkLogger.logHTTPResponse(response as? HTTPURLResponse)
                guard statusCode < 400 else {
                    Dispatch.async(Queue.serial) {
                        download.completionBlock(BadRequestError, nil, nil)
                    }
                    return
                }
                download.completionBlock(nil, location, nil)
            }
        }
        self.ongoingDownloads.removeValue(forKey:key)
    }
    
    func urlSession(_ session: URLSession,
                    downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        guard totalBytesExpectedToWrite > 0 else {
            return;
        }
        
        if let download = self.ongoingDownloads[(downloadTask.originalRequest?.url?.absoluteString)!],
           let progressBlock = download.progressBlock {
            let progress : CGFloat = CGFloat(totalBytesWritten) / CGFloat(totalBytesExpectedToWrite)
            Dispatch.async(Queue.serial) {
                progressBlock(progress)
            }
        }
    }
    
    //    func urlSession(_ session: URLSession,
    //                             task: URLSessionTask,
    //                             didCompleteWithError error: Error?) {
    //        let downloadTask = task as! URLSessionDownloadTask
    //        let key = (downloadTask.originalRequest?.url?.absoluteString)!
    //        if let download = self.ongoingDownloads[key] {
    //            Dispatch.async(Queue.serial) {
    //                download.completionBlock(NoResponseError, nil)
    //            }
    //        }
    //        self.ongoingDownloads.removeValue(forKey:key)
    //
    //    }
    
    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        session.getTasksWithCompletionHandler { (dataTasks, uploadTasks, downloadTasks) in
            if downloadTasks.count == 0 {
                Dispatch.async(Queue.serial) {
                    if let completion = self.backgroundCompletionHandler {
                        completion()
                    }
                    self.backgroundCompletionHandler = nil
                }
            }
        }
    }
}


final class FasmDownloadManager {
    
    static func remoteSync(config: FasmConfig, onCompletion:  @escaping (FasmError?, String?, String?, Dictionary<String, Any>?) -> Void) {
        
        // check config file exists
        // if yes, check ttl first and decide to connect to server.
        // fetch new config from server
        // get the local config json and compare it with the downloaded once and compare app version. if it is different download again and cache in temp folder
        // check host version (major) is modifed or not. If modifed then need to download both config json & zip folder.
        // also if config josn STRUCTURE only got modified at server, we need to download config JSON again
        
        let cachedConfigJson = FileUtility.loadJSON(path: FileUtility.getPath(name: config.cacheName!), withFilename: config.cacheName! + "_json.json")
        
        
        //check config is older than max cached date
//        let ttlDate = cachedConfigJson.cacheDate().toDate()
//        let currentDate = Date()
        
        // check cached app version & current app version is same or not
        let currentSemanticMajorAppVersion = config.hostVersion!.major()
        let cachedSemanticMajorAppVersion = cachedConfigJson.currentVersion().major()
        
//        if currentDate < ttlDate {
//            // config is still valid
//
//            // check current app version is matching to the cached one
//            if currentSemanticMajorAppVersion.isEqualToString(find: cachedSemanticMajorAppVersion)
//            {
//                // both cached & current app version matched.
//                // good to go with the cached one
//                FasmFileManager.localSync(directory: FileUtility.documentDirectory().appendingPathComponent(config.cacheName!), appVersion: config.hostVersion!, onCompletion: onCompletion)
//            }
//            else {
//                // though cached config is still valid, app version is changed as compared to the cached app version.
//                // fetch the config again
//                modifiedAppVersionSync(config: config, onCompletion: onCompletion)
//            }
//        }
//        else
//        {
            // config is outdated or may be first time loading. fetch again & compare any change to the cached app version zip url
            fetchConfig(config: config) { error, location in
                if error != nil {
                    
                    // in case of error, check whether current app version & cached version is same. If yes, sync old cache and go ahead with the cached content
                    if currentSemanticMajorAppVersion.isEqualToString(find: cachedSemanticMajorAppVersion)
                    {
                        FasmFileManager.localSync(directory: FileUtility.documentDirectory().appendingPathComponent(config.cacheName!), appVersion: config.hostVersion!, onCompletion: onCompletion)
                    }
                    else {
                        onCompletion(ConfigFetchError, nil, nil, nil)
                    }
                }
                else {
                    // config succeeded.
                    // check whether current app version & cached version is same. This check will happen susiqunt time only. Not valid for first time
                    if currentSemanticMajorAppVersion.isEqualToString(find: cachedSemanticMajorAppVersion)
                    {
                        // cached & current app version is same. Now check whether zip url got modifed at server end for the current app version. If yes, download again
                        
                        // config fetched. Now get the corresponding zip url bsed on the app version
                        revalidateZipURL(for: location!, config: config, onCompletion: onCompletion)
                    }
                    else {
                        
                        // first time config + zip downloading.
                        // config fetched. Now get the corresponding zip url bsed on the app version
                        currentAppVersionSync(for: location!, config: config, onCompletion: onCompletion)
                        
                    }
                }
                
            }
     //   }
        
    }
    
    fileprivate static func revalidateZipURL(for configData: FASMConfigData, config: FasmConfig, onCompletion:  @escaping (FasmError?, String?, String?, Dictionary<String, Any>?) -> Void) {
        
        let currentSemanticMajorAppVersion = config.hostVersion!.major()
        
        // load the newly donwloaded JSON to memory & if required write this json to default cache folder later.
        var updatedConfigJson = FileUtility.loadFASMJSON(configData: configData)
        
        let cachedConfigJson = FileUtility.loadJSON(path: FileUtility.getPath(name: config.cacheName!), withFilename: config.cacheName! + "_json.json")
        let cachedZipUrl = cachedConfigJson.zipUrl(appVersion: currentSemanticMajorAppVersion)
        let updatedZipUrl = updatedConfigJson.zipUrl(appVersion: currentSemanticMajorAppVersion)
        
        if let cachedZipUrl = cachedZipUrl,
           let updatedZipUrl = updatedZipUrl {
            
            if cachedZipUrl.isEqualToString(find: updatedZipUrl) {
                
                // update config json
                jsonWriteOperation(configJson: &updatedConfigJson, config: config)
                
                // web url is same. Good to go with the existing cache
                FasmFileManager.localSync(directory: FileUtility.documentDirectory().appendingPathComponent(config.cacheName!), appVersion: config.hostVersion!, onCompletion: onCompletion)
            }
            else {
                // though both cached app version & current app version is same. zip url got modifed. Download again
                fetchZip(zipUrl: updatedZipUrl, config: config) { zipError, zipLocation in
                    if zipError != nil {
                        // failed to download the updated zip url based on app version. However still old cache is valid here, where in both cached app version & current app version is same
                        FasmFileManager.localSync(directory: FileUtility.documentDirectory().appendingPathComponent(config.cacheName!), appVersion: config.hostVersion!, onCompletion: onCompletion)
                    }
                    else {
                        if let zipLocation = zipLocation {
                            
                            // write zip operation
                            zipWriteOperation(zipLocation: zipLocation, updatedZipUrl: updatedZipUrl, config: config, configJson: &updatedConfigJson, onCompletion: onCompletion)
                            
                        }
                        else {
                            // update config json
                            jsonWriteOperation(configJson: &updatedConfigJson, config: config)
                            
                            // location not found. May happen because of disk full. However old cache still valid
                            FasmFileManager.localSync(directory: FileUtility.documentDirectory().appendingPathComponent(config.cacheName!), appVersion: config.hostVersion!, onCompletion: onCompletion)
                        }
                        
                    }
                }
                
            }
        }
        else
        {
            // Rare case, where in either updatedZipUrl or cachedZipUrl may empty.
            // just sync old cache in this case
            FasmFileManager.localSync(directory: FileUtility.documentDirectory().appendingPathComponent(config.cacheName!), appVersion: config.hostVersion!, onCompletion: onCompletion)
        }
        
    }
    
    fileprivate static func currentAppVersionSync(for configData: FASMConfigData, config: FasmConfig, onCompletion:  @escaping (FasmError?, String?, String?, Dictionary<String, Any>?) -> Void) {
        
        let currentSemanticMajorAppVersion = config.hostVersion!.major()
        
        // load the newly donwloaded JSON to memory & if required write this json to default cache folder later.
        var updatedConfigJson = FileUtility.loadFASMJSON(configData: configData)
        
        //get the zip url for the current app version
        let updatedZipUrl = updatedConfigJson.zipUrl(appVersion: currentSemanticMajorAppVersion)
        
        if updatedZipUrl != nil {
            
            // download the zip
            fetchZip(zipUrl: updatedZipUrl!, config: config) { zipError, zipLocation in
                if zipError != nil {
                    // failure case. Update partner app
                    onCompletion(NoResponseError, nil, nil, nil)
                }
                else {
                    // first time download is success.
                    if let zipLocation = zipLocation
                    {
                        // write zip to temp cache name folder
                        zipWriteOperation(zipLocation: zipLocation, updatedZipUrl: updatedZipUrl!, config: config, configJson: &updatedConfigJson, onCompletion: onCompletion)
                    }
                    else {
                        // location not found. May happen because of disk full
                        onCompletion(FileWriteError, nil, nil, nil)
                    }
                    
                }
            }
        }
        else {
            // failure case. Update partner app
            onCompletion(VersionError, nil, nil, nil)
        }
        
    }
    
    fileprivate static func modifiedAppVersionSync(config: FasmConfig, onCompletion:  @escaping (FasmError?, String?, String?, Dictionary<String, Any>?) -> Void) {
        
        let currentSemanticMajorAppVersion = config.hostVersion!.major()
        
        fetchConfig(config: config) { error, location in
            if error != nil {
                // for the updated app version, we didn't get the corresponding json response. Notify app
                onCompletion(error, nil, nil, nil)
            }
            else {
                // config fetched. Now get the corresponding zip url bsed on the app version
                // load the newly donwloaded JSON to memory & if required write this json to default cache folder later.
                var updatedConfigJson = FileUtility.loadFASMJSON(configData: location!)
                
                // get the web url from updated json
                let updatedZipUrl = updatedConfigJson.zipUrl(appVersion: currentSemanticMajorAppVersion)
                
                if updatedZipUrl != nil {
                    // time to download the corresponding zip
                    fetchZip(zipUrl: updatedZipUrl!, config: config) { zipError, zipLocation in
                        if zipError != nil {
                            // failed to download the corresponding zip folder based on app version. Notify the partner app
                            onCompletion(zipError, nil, nil, nil)
                        }
                        else {
                            // crucial part. Downloaded zip will be written to the cache folder along with the config json
                            // to handle system failure during read/write operation, utilise file custom attribute - custom attribute
                            
                            if let zipLocation = zipLocation
                            {
                                // write zip to temp cache name folder
                                zipWriteOperation(zipLocation: zipLocation, updatedZipUrl: updatedZipUrl!, config: config, configJson: &updatedConfigJson, onCompletion: onCompletion)
                            }
                            else {
                                // location not found. May happen because of disk full
                                onCompletion(FileWriteError, nil, nil, nil)
                            }
                            
                        }
                    }
                }
                else {
                    // this case will happen, in case for the updated app version, corresponding web folder not deployed at server
                    onCompletion(VersionError, nil, nil, nil)
                }
            }
        }
        
    }
    
    fileprivate static func zipWriteOperation(zipLocation: URL, updatedZipUrl: String, config: FasmConfig, configJson: inout [String: Any], onCompletion:  @escaping (FasmError?, String?, String?, Dictionary<String, Any>?) -> Void) {
        
        let currentSemanticMajorAppVersion = config.hostVersion!.major()
        let checksumFromConfig = configJson.getChecksum(appVersion: currentSemanticMajorAppVersion)
        let checksumOfZipFile = try? Data(contentsOf: zipLocation).hash256()
        
        guard checksumFromConfig == "" || checksumFromConfig.isEmpty || checksumFromConfig == checksumOfZipFile else {
            onCompletion(ChecksumError, nil, nil, nil)
            return
        }
        let destinationURL = zipLocation.deletingPathExtension()
        let zipPath = zipLocation.deletingPathExtension().appendingPathExtension("zip")
        FileUtility.move(from: zipLocation, to: zipPath, completion:{ _, _ in})
        FileUtility.createDirectoryAt(path: destinationURL)
        FileUtility.unzip(from: zipPath, to: destinationURL)
        
        // delete cache folder entirely before writing new cache.
        FileUtility.deleteDirectoryIfExistsAtPath(path: FileUtility.documentDirectory().appendingPathComponent(config.cacheName!))
        
        // final pcached path will be cacheName + get ONLY path from the actual zip url
        let remoteURLPath = URL(string: updatedZipUrl)!.path.stringByDeletingLastPathComponent()
        let finalCacheDestinationURL = FileUtility.documentDirectory().appendingPathComponent(config.cacheName! + remoteURLPath)
        
        FileUtility.createDirectoryAt(path: finalCacheDestinationURL)
        
        // for whatever reason, un-zipping is creating intermediate "main" folder. TODO: Fix is required
        // As a patch fix, in case un-zipping is creating any intermediate folder, make sure we will copy the content inside of main folder
        if  FileUtility.isDirectoryExists(path: destinationURL.appendingPathComponent("main")) {
            FileUtility.move(from: destinationURL.appendingPathComponent("main"), to: finalCacheDestinationURL, completion: {_,_ in})
        }
        else {
            FileUtility.move(from: destinationURL, to: finalCacheDestinationURL, completion: {_,_ in})
        }
        
        // FileUtility.move(from: destinationURL, to: finalCacheDestinationURL, completion: {_,_ in})
        
        // update the current version of json cache & update write operation is succeeded.
        jsonWriteOperation(configJson: &configJson, config: config)
        
        // time to sync & update to partner app if required
        FasmFileManager.localSync(directory: FileUtility.documentDirectory().appendingPathComponent(config.cacheName!), appVersion: config.hostVersion!, onCompletion: onCompletion)
        
    }
    
    fileprivate static func jsonWriteOperation(configJson: inout [String: Any], config: FasmConfig) {
        
        configJson.updateValue(config.hostVersion!, forKey: ConfigKeys.CURRENT_VERSION)
        configJson.updateValue(true, forKey: ConfigKeys.STATUS)
        
        // explicitly set future date as validity for config json based on current date + ttl
        let cacheAge = Date().addingTimeInterval(configJson.ttl())
        configJson.updateValue(cacheAge.toDateString(), forKey: ConfigKeys.MAX_CACHE_VALIDITY_DATE)
        
        let jsonFileName = config.cacheName! + "_json.json"
        let jsonWritePath = FileUtility.documentDirectory().appendingPathComponent(config.cacheName!).appendingPathComponent(jsonFileName)
        
        FileUtility.writeJson(json: configJson, to: jsonWritePath)
    }
    
    fileprivate static func fetchConfig(config: FasmConfig, onCompletion:  @escaping (FasmError?, _ localURL: FASMConfigData?) -> Void) {
        
        let requestUrl = URL(string: config.configURL!)!
        var request = URLRequest(url: requestUrl)
        
        let cachedConfigJson = FileUtility.loadJSON(path: FileUtility.getPath(name: config.cacheName!), withFilename: config.cacheName! + "_json.json")
        let cachedAppVersion = cachedConfigJson.currentVersion()
        if let hostVersion = config.hostVersion, !(hostVersion.isEqualToString(find: cachedAppVersion)) {
            request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
        }
        DownloadUtility.shared.downloadConfig(request: request, onProgress: { _ in }, onPinningRequest: {
            return config.pinningKeyList
        }, onCompletion: { error,_,fasmConfigData  in
            onCompletion(error,fasmConfigData)
        })
    }
    
    fileprivate static func fetchZip(zipUrl: String, config: FasmConfig, onCompletion:  @escaping (FasmError?, _ localURL: URL?) -> Void) {
        let requestUrl = URL(string: zipUrl)!
        _ = DownloadUtility.shared.download(request: URLRequest(url: requestUrl), shouldDownloadInBackground: false, onProgress: { _ in }, onPinningRequest: {
            return nil
        }, onCompletion: { error,location,_ in
            onCompletion(error,location)
        })
    }
}
//
//extension DownloadUtility : URLSessionTaskDelegate {
//    func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics){
//         for (_, value) in metrics.transactionMetrics.enumerated() {
//             switch value.resourceFetchType {
//             case .networkLoad:
//                 print("Network Load")
//                 break
//             case .unknown:
//                 print("unknown")
//                 break
//             case .serverPush:
//                 print("Server Push")
//                 break
//             case .localCache:
//                 print("Local Cache")
//                 break
//             default:
//                 print("Default")
//            }
//       }
//    }
//func urlSession(_ session: URLSession, dataTask: URLSessionDataTask,
//                willCacheResponse proposedResponse: CachedURLResponse,
//                completionHandler: @escaping (CachedURLResponse?) -> Void) {
//    if proposedResponse.response.url?.scheme == "https" {
//        let updatedResponse = CachedURLResponse(response: proposedResponse.response,
//                                                data: proposedResponse.data,
//                                                userInfo: proposedResponse.userInfo,
//                                                storagePolicy: .allowedInMemoryOnly)
//        completionHandler(updatedResponse)
//    } else {
//        completionHandler(proposedResponse)
//    }
//}
//}
