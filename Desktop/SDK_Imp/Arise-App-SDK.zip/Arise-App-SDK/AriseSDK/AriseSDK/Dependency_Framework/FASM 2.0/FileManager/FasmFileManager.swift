//
//  ZipFileManager.swift
//  Zip
//
//  Created by Prasanna on 22/09/21.
//

import Foundation

final class FasmFileManager {
    
    static func localSync(directory: URL, appVersion: String,
                          onCompletion: @escaping (FasmError?, String?, String?, Dictionary<String, Any>?) -> Void) {
        
        // Check previuos write operation to cache folder is succeeded or not
        let jsonPath = directory.appendingPathComponent(directory.folerName() + "_json.json")
        let configJson = FileUtility.loadJSON(path: jsonPath)
        if configJson.syncStatus() == true {
            
            let configData = getConfigData(json: configJson, appVersion: appVersion)
            onCompletion(nil, directory.absoluteString, configData.webUrl, configData.extraData)
        }
        else {
            // delete the corrupted cache folder. As it didn't sync successfully.
            FileUtility.deleteDirectoryIfExistsAtPath(path: directory)
            
            // Not found old cache.
            onCompletion(nil, nil, nil, nil)
        }
    }
    
    fileprivate static func getConfigData(json: Dictionary<String, Any>, appVersion: String) -> (extraData: Dictionary<String, Any>?, webUrl: String?) {
        let extraData = json.extraData()
        let webUrl = json.webUrl(appVersion: appVersion)
        return (extraData, webUrl)
    }
    
}


