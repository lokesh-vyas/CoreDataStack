//
//  ZipDownloadObject.swift
//  CanvasKit
//
//  Created by Prasanna on 23/08/21.
//

import Foundation
import UIKit

typealias DownloadCompletionBlock = (_ error : FasmError?, _ fileUrl: URL? , _ fasmConfigData : FASMConfigData?) -> Void
typealias DownloadProgressBlock = (_ progress : CGFloat) -> Void
typealias BackgroundDownloadCompletionHandler = () -> Void
typealias PinningBlock = () -> [String]?

final class FasmDownloadObject: NSObject {
    
    var completionBlock: DownloadCompletionBlock
    var progressBlock: DownloadProgressBlock?
    let downloadTask: URLSessionTask
    
    init(downloadTask: URLSessionTask, progressBlock: DownloadProgressBlock?, completionBlock: @escaping DownloadCompletionBlock) {
        self.downloadTask = downloadTask
        self.progressBlock = progressBlock
        self.completionBlock = completionBlock
    }
}

// MARK: - FASMConfigData
struct FASMConfigData: Codable {
    let configData: ConfigData
    let extraData: ExtraData

    enum CodingKeys: String, CodingKey {
        case configData = "config_data"
        case extraData = "extra_data"
    }
}

// MARK: - ConfigData
struct ConfigData: Codable {
    let webURLData: [String: WebURLDatum]
    let ttl: Int
    let assetsResources: AssetsResources

    enum CodingKeys: String, CodingKey {
        case webURLData = "web_url_data"
        case ttl
        case assetsResources = "assets_resources"
    }
}

// MARK: - AssetsResources
struct AssetsResources: Codable {
}

// MARK: - WebURLDatum
struct WebURLDatum: Codable {
    let zipURL: String
    let webURL: String
    let webVersion: String

    enum CodingKeys: String, CodingKey {
        case zipURL = "zip_url"
        case webURL = "web_url"
        case webVersion = "web_version"
    }
}

// MARK: - ExtraData
struct ExtraData: Codable {
    let whitelistingUrls: [String]

    enum CodingKeys: String, CodingKey {
        case whitelistingUrls = "whitelisting_urls"
    }
}
