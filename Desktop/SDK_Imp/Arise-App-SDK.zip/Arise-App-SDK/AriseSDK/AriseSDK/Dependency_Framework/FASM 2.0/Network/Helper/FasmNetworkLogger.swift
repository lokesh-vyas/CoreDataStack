//
//  ZipNetworkLogger.swift
//  Zip
//
//  Created by Prasanna on 22/09/21.
//

import Foundation

// Icon representation for netwrok response
let ResponseStatusIcon = [
    1: "ℹ️", // 1xx - ["Informational]
    2: "✅", // 2xx - ["Success"]
    3: "⤴️", // 3xx - ["Redirection"]
    4: "⛔️", // 4xx - ["Clinet Error"]
    5: "❌"  // 5xx  - ["Server Error"]
]


// Text representation for network response
let ResponseStatusString = [
    // 1xx (Informational)
    100: "Continue",
    101: "Switching Protocols",
    102: "Processing",
    
    // 2xx (Success)
    200: "OK",
    201: "Created",
    202: "Accepted",
    203: "Non-Authoritative Information",
    204: "No Content",
    205: "Reset Content",
    206: "Partial Content",
    207: "Multi-Status",
    208: "Already Reported",
    226: "IM Used",
    
    // 3xx (Redirection)
    300: "Multiple Choices",
    301: "Moved Permanently",
    302: "Found",
    303: "See Other",
    304: "Not Modified",
    305: "Use Proxy",
    306: "Switch Proxy",
    307: "Temporary Redirect",
    308: "Permanent Redirect",
    
    // 4xx (Client Error)
    400: "Bad Request",
    401: "Unauthorized",
    402: "Payment Required",
    403: "Forbidden",
    404: "Not Found",
    405: "Method Not Allowed",
    406: "Not Acceptable",
    407: "Proxy Authentication Required",
    408: "Request Timeout",
    409: "Conflict",
    410: "Gone",
    411: "Length Required",
    412: "Precondition Failed",
    413: "Request Entity Too Large",
    414: "Request-URI Too Long",
    415: "Unsupported Media Type",
    416: "Requested Range Not Satisfiable",
    417: "Expectation Failed",
    418: "I'm a teapot",
    420: "Enhance Your Calm",
    422: "Unprocessable Entity",
    423: "Locked",
    424: "Method Failure",
    425: "Unordered Collection",
    426: "Upgrade Required",
    428: "Precondition Required",
    429: "Too Many Requests",
    431: "Request Header Fields Too Large",
    451: "Unavailable For Legal Reasons",
    
    // 5xx (Server Error)
    500: "Internal Server Error",
    501: "Not Implemented",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
    505: "HTTP Version Not Supported",
    506: "Variant Also Negotiates",
    507: "Insufficient Storage",
    508: "Loop Detected",
    509: "Bandwidth Limit Exceeded",
    510: "Not Extended",
    511: "Network Authentication Required"
]

let HttpMethodIcon = [
    "POST":   "⬆️",
    "GET":    "⬇️",
    "PUT":    "↔️",
    "PATCH":  "🔃",
    "DELETE": "⏹"
]

class FasmNetworkLogger {
    
    enum LoggerType: Int {
        case response = 0
        case request
    }
    
     static func logHTTPRequest(_ request: URLRequest?, _ loggerType: LoggerType = LoggerType.request) -> () {
        
        if let request = request {
            
            
            var s = "---------------------------------------------------------------------\n"
            
            if let method = request.httpMethod {
                s += "\(HttpMethodIcon[method]!) => "
                s += "\(method) "
            }
           
            if let url = request.url {
                s += "'\(absoluteStringByTrimmingQuery(url))' "
                
                s += logQueryParam(url.absoluteString)
            }
            
            
            if let headers = request.allHTTPHeaderFields , headers.count > 0 {
                s += "\n" + logHeaders(headers as [String : AnyObject])
            }
        
            s += "\n" + bodyString(request.httpBody,loggerType)
            s += "\n---------------------------------------------------------------------\n"
            AriseLogger().LogD(value: s)
        }
       
    }
    static func logHTTPResponse(_ response: HTTPURLResponse?,data: Data? = nil,_ loggerType: LoggerType = LoggerType.response) -> () {
       
        if let response = response {
            var s = "---------------------------------------------------------------------\n"
            if let url = response.url?.absoluteString {
                s += "\(url) "
            }
            
            
            s += "("
            
            let iconNumber = Int(floor(Double(response.statusCode) / 100.0))
            if let iconString = ResponseStatusIcon[iconNumber] {
                s += "\(iconString) "
            }
            
            
            s += "\(response.statusCode)"
            if let statusString = ResponseStatusString[response.statusCode] {
                s += " \(statusString)"
            }
            s += ")"
            s += "\n" + bodyString(data, loggerType)
            s += "\n---------------------------------------------------------------------\n"
            AriseLogger().LogD(value: s)
            
        }
        
    }
    
   static private func logHeaders(_ headers: [String: AnyObject]) -> String {
        var s = "Headers: [\n"
        for (key, value) in headers {
            s += "\t\(key) : \(value)\n"
        }
        s += "]"
        return s
    }
    
    static private func logQueryParam(_ url: String) -> String {
        
        var s: String = ""
        let queryItems = URLComponents(string: url)?.queryItems
        if let queryItems = queryItems {
            s = "\n" + "Query parameters: [\n"
            for query in queryItems.enumerated() {
                s += "\t\(query.element.name) : \(query.element.value ?? "")\n"
            }
            s += "]"
        }
        
        return s
    }
    
    static private func absoluteStringByTrimmingQuery(_ url: URL) -> String {
        
        if var urlcomponents = URLComponents(url: url, resolvingAgainstBaseURL: false) {
            urlcomponents.query = nil
            return urlcomponents.string ?? ""
        }
        return ""
    }
    
    static private func bodyString(_ body: Data?, _ loggerType: LoggerType) -> String {
        
        if let body = body {
            var s: String = ""
            s = "\n" +  ((loggerType == LoggerType.request) ? "Request Body: \n" : "Response Body: \n")
            
            if let json = try? JSONSerialization.jsonObject(with: body, options: .mutableContainers),
                let pretty = try? JSONSerialization.data(withJSONObject: json, options: .prettyPrinted),
                let string = String(data: pretty, encoding: String.Encoding.utf8) {
                s += "\t" + string + "\n"
                return s
                
            } else if let string = String(data: body, encoding: String.Encoding.utf8) {
                
                if !string.isEmpty {
                    s += "\t\(string)\n"
                    return s
                }
                else {
                    return ""
                }
            } else {
                if !body.description.isEmpty {
                    s += "\t\(body.description)\n"
                    return s
                }
                else
                {
                    return ""
                }
            }
        } else {
            return ""
        }
    }
}
