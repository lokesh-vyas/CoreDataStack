//
//  Helper.swift
//  Zip
//
//  Created by Prasanna on 29/09/21.
//

import Foundation
import CommonCrypto
import CryptoKit

struct ConfigKeys {
    static let CONFIG_DATA = "config_data"
    static let WEB_URL_DATA = "web_url_data"
    static let TTL = "ttl"
    static let EXTRA_DATA = "extra_data"
    static let WHITELISTENING_URL = "whitelisting_urls"
    static let WEB_URL = "web_url"
    static let ZIP_URL = "zip_url"
    static let CURRENT_VERSION = "current_version"
    static let STATUS = "status"
    static let MAX_CACHE_VALIDITY_DATE = "MAX_CACHE_DATE"
    static let CONFIG_URL = "CONFIG_URL"
    static let CHECKSUM = "checksum"
    static let WEB_VERSION = "web_version"
}
extension URL {
    
    func fileName() -> String {
        return self.deletingPathExtension().lastPathComponent
    }
    
    func folerName() -> String {
        return self.lastPathComponent
    }
}
extension String {
    
    var ns: NSString {
        return self as NSString
    }
    
    func major() -> String {
        let major = self.components(separatedBy: ".").first ?? ""
        return major
    }
    
    func isEqualToString(find: String) -> Bool {
        return String(format: self) == find
    }
    
    func fileExtension() -> String {
        return NSURL(fileURLWithPath: self).pathExtension?.lowercased() ?? ""
    }
    
    func stringByDeletingLastPathComponent() -> String {
        return ns.deletingLastPathComponent
    }
    
    func toDate() -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        guard let date = dateFormatter.date(from: self) else {
          return Date()
        }
        return date
        
      }
}

extension Date {
    func toDateString() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return dateFormatter.string(from: self)
        
    }
}

extension Dictionary where Key == String {
    func value(from key: Key) -> Value? {
        return self[key]
    }
    
    func configData() -> Dictionary? {
        return value(from: ConfigKeys.CONFIG_DATA) as? Dictionary
    }
    
    func extraData() -> Dictionary? {
        return value(from: ConfigKeys.EXTRA_DATA) as? Dictionary
    }
    
    func webUrlData() -> Dictionary? {
        let configData = self.configData()
        return configData?.value(from:  ConfigKeys.WEB_URL_DATA) as? Dictionary
    }
    
    func urls(appVersion: String) -> Dictionary? {
        let major = appVersion.major()
        return self.webUrlData()?.value(from: major) as? Dictionary
    }
    
    func ttl() -> TimeInterval {
        let configData = self.configData()
        return configData?.value(from: ConfigKeys.TTL) as? TimeInterval ?? 0.0
    }
    
    func webUrl(appVersion: String) -> String? {
        let urls = self.urls(appVersion: appVersion)
        return urls?.value(from: ConfigKeys.WEB_URL) as? String
     }
    
    func zipUrl(appVersion: String) -> String? {
        let urls = self.urls(appVersion: appVersion)
        return urls?.value(from: ConfigKeys.ZIP_URL) as? String
     }
    
    func currentVersion() -> String {
        return value(from: ConfigKeys.CURRENT_VERSION) as? String ?? ""
    }
    
    func syncStatus() -> Bool {
        return value(from: ConfigKeys.STATUS) as? Bool ?? false
    }
    
    func cacheDate() -> String {
        return value(from: ConfigKeys.MAX_CACHE_VALIDITY_DATE) as? String ?? ""
    }
    func cachedConfigUrl() -> String {
        return value(from: ConfigKeys.CONFIG_URL) as? String ?? ""
    }
    
    func getChecksum(appVersion: String) -> String {
        let urls = self.urls(appVersion: appVersion)
        return urls?.value(from: ConfigKeys.CHECKSUM) as? String ?? ""
    }
    
    func getWebVersion(appVersion: String) -> String {
        let urls = self.urls(appVersion: appVersion)
        return urls?.value(from: ConfigKeys.WEB_VERSION) as? String ?? ""
    }
}

internal extension Data {
    func hash256() -> String {
        let inputData = self
        
        if #available(iOS 13.0, *) {
            let hashed = SHA256.hash(data: inputData)
            return hashed.compactMap { String(format: "%02x", $0) }.joined()
        } else {
            var digest = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
            inputData.withUnsafeBytes { bytes in
                _ = CC_SHA256(bytes.baseAddress, UInt32(inputData.count), &digest)
            }
            return digest.makeIterator().compactMap { String(format: "%02x", $0) }.joined()
        }
    }
}
