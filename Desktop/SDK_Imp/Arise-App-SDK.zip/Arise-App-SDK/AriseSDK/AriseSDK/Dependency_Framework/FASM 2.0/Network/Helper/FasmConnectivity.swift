//
//  ZipConnectivity.swift
//  Zip
//
//  Created by Prasanna on 22/09/21.
//

import Foundation

struct FasmConnectivity {
    static let sharedInstance = AriseNetworkReachabilityManager()!
    public static var isConnectedToInternet:Bool {
        return self.sharedInstance.isReachable
    }
}
