//
//  FileUtility.swift
//  Zip
//
//  Created by Prasanna on 24/09/21.
//

import Foundation

struct FileUtility {
    
    static func documentDirectory() -> URL {
        let directoryPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        return URL(fileURLWithPath: directoryPath)
    }
    
    static func deleteDirectoryIfExists(name: String)  {
        let directoryUrl = self.documentDirectory().appendingPathComponent(name)
        deleteDirectoryIfExistsAtPath(path: directoryUrl)
    }
    
    static func deleteDirectoryIfExistsAtPath(path: URL) {
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: path.path) {
            try? FileManager.default.removeItem(at: path.absoluteURL)
        }
    }
    
    static func isDirectoryExists(path: URL) -> Bool {
        return FileManager.default.fileExists(atPath: path.path)
    }
    
    static func move(from: String, to directoryName: String, completion: @escaping (FasmError?, URL?) -> Void){
        
        self.deleteDirectoryIfExists(name: directoryName)
        
        do {
            try FileManager.default.moveItem(at: self.documentDirectory().appendingPathComponent(from), to:  self.documentDirectory().appendingPathComponent(directoryName))
            completion(nil, self.documentDirectory().appendingPathComponent(directoryName))
        } catch {
            completion(FileMoveError, nil)
        }
    }
    
    static func move(from: URL, to: URL, completion: @escaping (FasmError?, URL?) -> Void){
        deleteDirectoryIfExistsAtPath(path: to)
        do {
            //try FileManager.default.moveItem(atPath: from.absoluteString, toPath: to.absoluteString)
            try FileManager.default.moveItem(at: from, to: to)
            completion(nil, to)
        } catch  {
            completion(FileMoveError, nil)
        }
        
    }
    
    static func loadFASMJSON(configData: FASMConfigData) -> [String: Any]
    {
        let jsonEncoder = JSONEncoder()
        let jsonData = try? jsonEncoder.encode(configData)
        let jsonString = String(decoding: jsonData ?? Data(), as: UTF8.self)
        let jsonObject = self.convertStringToDictionary(string: jsonString)
        return jsonObject ?? [String: Any]()
    }
    
    static func loadJSON(path: URL, withFilename filename: String) -> [String: Any] {
        let pathUrl = path.appendingPathComponent(filename)
        return loadJSON(path: pathUrl)
    }

    static func loadJSON(path: URL) -> [String: Any]
    {
        let data = try? Data(contentsOf: path)
        let jsonString = String(decoding: data ?? Data(), as: UTF8.self)
        let jsonObject = self.convertStringToDictionary(string: jsonString)
        return jsonObject ?? [String: Any]()
    }
    
    static func convertStringToDictionary(string: String) -> [String: Any]? {
        
        if let data = string.data(using: String.Encoding.utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? Dictionary
            } catch  {}
        }
        return nil
    }
    
    static func writeJson(json: [String: Any], to: URL) {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: json, options: .prettyPrinted)
            try jsonData.write(to: to)
        } catch {}
    }
    
    static func createDirectory(name: String) -> URL {
        self.deleteDirectoryIfExists(name: name)
        return createDirectoryAt(path: self.documentDirectory().appendingPathComponent(name))
    }
    
    @discardableResult
    static func createDirectoryAt(path: URL) -> URL {
        self.deleteDirectoryIfExists(name: path.fileName())
        do {
            try FileManager.default.createDirectory(at: path, withIntermediateDirectories: true, attributes: nil)
        } catch _ { }
        return path
    }
    
    static func unzip(from: URL, to: URL) {
        let fileManager = FileManager.default
        try? fileManager.unzipItem(at: from, to: to)
    }
    
    static func getPath(name: String) -> URL {
        let directoryUrl = self.documentDirectory().appendingPathComponent(name)
        return directoryUrl
    }
}
