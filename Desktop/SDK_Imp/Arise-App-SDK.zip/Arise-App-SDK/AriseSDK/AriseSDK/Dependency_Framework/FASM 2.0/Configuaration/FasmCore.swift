//
//  ZipCore.swift
//  Zip
//
//  Created by Prasanna on 22/09/21.
//

import Foundation

@objc public final class FasmCore: NSObject {
    
    public static func sync(config: FasmConfig,
                             onCompletion: @escaping (String, String?, [String: Any]?) -> Void,
                             onError:  @escaping (FasmError) -> Void) {
        
        // all operations are happening on serial queue. Doesn't impact main thread
      Dispatch.async(Queue.serial) {
            
            //check zip config initialised or not
            guard let cacheName = config.cacheName?.trimmingCharacters(in: .whitespacesAndNewlines),
                cacheName.count > 0,
                let configURL = config.configURL,
                let _ = URL(string: configURL),
                let appVersion = config.hostVersion?.trimmingCharacters(in: .whitespacesAndNewlines),
                appVersion.count > 0 else {
                Dispatch.async(Queue.main, closure: {
                    onError(ConfigError)
                })
                return
            }
            
            // connect to server & update partner app, if required
            FasmDownloadManager.remoteSync(config: config) { error, localUrl, webUrl, extraData in
                if localUrl != nil {
                    Dispatch.async(.main) {
                        onCompletion(localUrl!, webUrl, extraData)
                    }
                }
                else {
                    Dispatch.async(Queue.main, closure: {
                        onError(error!)
                    })
                }
            }
        }
    }
}
