//
//  ZipError.swift
//  Zip
//
//  Created by Prasanna on 22/09/21.
//

import Foundation

let NoInternetError = FasmError(localizedTitle: "Network Error", localizedDescription: "You are not connected to network", code: 401)
let EmptyURLError = FasmError(localizedTitle: "Network Error", localizedDescription: "Invalid request URL", code: 402)
let DuplicateRequestError = FasmError(localizedTitle: "Network Error", localizedDescription: "Duplicate request URL", code: 403)
let BadRequestError = FasmError(localizedTitle: "Network Error", localizedDescription: "Bad request URL", code: 404)
let NoResponseError = FasmError(localizedTitle: "Network Error", localizedDescription: "No response from remote host", code: 405)
let FileRemoveError = FasmError(localizedTitle: "I/O Error", localizedDescription: "Failed to remove old content", code: 406)
let FileMoveError = FasmError(localizedTitle: "I/O Error", localizedDescription: "Failed to move new content", code: 407)
let ConfigError = FasmError(localizedTitle: "Config Error", localizedDescription: "Initialisation failed. Make sure zip config parameters are valid", code: 408)
let VersionError = FasmError(localizedTitle: "Version Error", localizedDescription: "Deployment for the current app version is pending at server end", code: 409)
let FileWriteError = FasmError(localizedTitle: "I/O Error", localizedDescription: "File location not found", code: 410)
let ConfigFetchError = FasmError(localizedTitle: "Config Fecth Error", localizedDescription: "Failed to fetch config response", code: 411)
let ChecksumError = FasmError(localizedTitle: "Checksum Error", localizedDescription: "Checksum does not match", code: 412)

protocol FasmErrorProtocol : Error{
    var localizedTitle: String { get }
    var localizedDescription: String { get }
    var code: Int { get }
}

public struct FasmError: FasmErrorProtocol {
    
    public var localizedTitle: String
    var localizedDescription: String
    public var code: Int
    
    init(localizedTitle: String?, localizedDescription: String, code: Int) {
        self.localizedTitle = localizedTitle ?? "Error"
        self.localizedDescription = localizedDescription
        self.code = code
    }
}
