//
//  Dispatch.swift
//  Zip
//
//  Created by Prasanna on 24/09/21.
//

import Foundation

typealias DispatchClosure = () -> (Void)

struct Queue {
    
    fileprivate enum Atribute {
        case concurrent
        case serial
        
        typealias RawValue = DispatchQueue.Attributes
        
        var rawValue: RawValue {
            switch self {
            case .concurrent:
                return DispatchQueue.Attributes.concurrent
            case .serial:
                return []
            }
        }
    }
    fileprivate enum Priority {
        case userInteractive
        case userInitiated
        case utility
        case background
        
        typealias RawValue = DispatchQoS.QoSClass
        
        var rawValue: RawValue {
            switch self {
            case .userInteractive: return DispatchQoS.QoSClass.userInteractive
            case .userInitiated: return DispatchQoS.QoSClass.userInitiated
            case .utility: return DispatchQoS.QoSClass.utility
            case .background: return DispatchQoS.QoSClass.background
            
            }
        }
    }
    fileprivate struct SerialQueue {
        static let serialQueue = DispatchQueue(label: "com.zip.sync", attributes: Queue.Atribute.serial.rawValue)
    }
    fileprivate static var mainQueue: DispatchQueue {
        return DispatchQueue.main
    }

    fileprivate static var globalQueue: (DispatchQoS.QoSClass) -> DispatchQueue = { priority in
        return DispatchQueue.global(qos: priority)
    }
    
    fileprivate static var custom: DispatchQueue {
        return SerialQueue.serialQueue
    }
}

extension Queue {
    static var globalUserInteractive: DispatchQueue { return globalQueue(Queue.Priority.userInteractive.rawValue) }
    static var globalUserInitiated: DispatchQueue { return globalQueue(Queue.Priority.userInitiated.rawValue) }
    static var globalUtility: DispatchQueue { return globalQueue(Queue.Priority.utility.rawValue) }
    static var globalBackground: DispatchQueue { return globalQueue(Queue.Priority.background.rawValue) }
    static var main: DispatchQueue { return mainQueue }
    static var serial: DispatchQueue { return custom }
}


struct Dispatch {
  fileprivate let currentItem: DispatchWorkItem
  fileprivate init(_ closure: @escaping DispatchClosure) {
    let item = DispatchWorkItem(flags: DispatchWorkItemFlags.inheritQoS, block: closure)
    currentItem = item
  }
}

extension Dispatch {
    @discardableResult
    static func async(_ queue: DispatchQueue, closure: @escaping DispatchClosure) -> Dispatch {
        let dispatch = Dispatch(closure)
        queue.async(execute: dispatch.currentItem)
        return dispatch
    }
    @discardableResult
    static func sync(_ queue: DispatchQueue, closure: @escaping DispatchClosure) -> Dispatch {
        let dispatch = Dispatch(closure)
        if (queue == Queue.main) && Thread.isMainThread {
            dispatch.currentItem.perform()
        } else {
            queue.sync(execute: dispatch.currentItem)
        }
        return dispatch
    }
}
