
#import <Foundation/Foundation.h>

@interface DSCallInfo : NSObject
@property (nullable, nonatomic) NSString* method;
@property (nullable, nonatomic) NSNumber* id;
@property (nullable,nonatomic) NSArray * args;
@end
