//
//  AriseSpinner.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 19/07/21.
//

import Foundation
import UIKit

@IBDesignable
class AriseSpinnerView : UIView {
    override var layer: CAShapeLayer {
        get {
            return super.layer as! CAShapeLayer
        }
    }
    
    override class var layerClass: AnyClass {
        return CAShapeLayer.self
    }
    
    var customWidth: CGFloat = 4 // defaulting to 5 width for normal cases
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layer.fillColor = nil
        layer.strokeColor = UIColor.darkRed.cgColor
        layer.lineWidth = self.customWidth
        setPath()
    }
    
    func setCustomWidth(_ customWidth: CGFloat) -> AriseSpinnerView{
        self.customWidth = customWidth
        self.layoutSubviews()
        return self
    }
    
    override func didMoveToWindow() {
        animate()
    }
    
    private func setPath() {
        layer.path = UIBezierPath(ovalIn: bounds.insetBy(dx: layer.lineWidth / 2, dy: layer.lineWidth / 2)).cgPath
    }
    
    struct Pose {
        let secondsSincePriorPose: CFTimeInterval
        let start: CGFloat
        let length: CGFloat
        init(_ secondsSincePriorPose: CFTimeInterval, _ start: CGFloat, _ length: CGFloat) {
            self.secondsSincePriorPose = secondsSincePriorPose
            self.start = start
            self.length = length
        }
    }
    
    class var poses: [Pose] {
        get {
            return [
                Pose(0.0, 0.000, 0.8),
                Pose(0.4, 0.500, 0.5),
                Pose(0.4, 1.000, 0.3),
                Pose(0.4, 1.500, 0.1),
                Pose(0.4, 1.875, 0.1),
                Pose(0.4, 2.250, 0.3),
                Pose(0.4, 2.625, 0.5),
                Pose(0.4, 3.000, 0.8),
            ]
        }
    }
    
    func animate() {
        var time: CFTimeInterval = 0
        var times = [CFTimeInterval]()
        var start: CGFloat = 0
        var rotations = [CGFloat]()
        var strokeEnds = [CGFloat]()
        
        let poses = type(of: self).poses
        let totalSeconds = poses.reduce(0) { $0 + $1.secondsSincePriorPose }
        
        for pose in poses {
            time += pose.secondsSincePriorPose
            times.append(time / totalSeconds)
            start = pose.start
            rotations.append(start * 2 * .pi)
            strokeEnds.append(pose.length)
        }
        
        times.append(times.last!)
        rotations.append(rotations[0])
        strokeEnds.append(strokeEnds[0])
        
        animateKeyPath(keyPath: "strokeEnd", duration: totalSeconds, times: times, values: strokeEnds)
        animateKeyPath(keyPath: "transform.rotation", duration: totalSeconds, times: times, values: rotations)
        
    }
    
    func animateKeyPath(keyPath: String, duration: CFTimeInterval, times: [CFTimeInterval], values: [CGFloat]) {
        let animation = CAKeyframeAnimation(keyPath: keyPath)
        animation.keyTimes = times as [NSNumber]?
        animation.values = values
        animation.calculationMode = .linear
        animation.duration = duration
        animation.repeatCount = Float.infinity
        layer.add(animation, forKey: animation.keyPath)
    }
}

extension UIView {
    
    struct AriseLoaderAssociatedKeys {
        static var stateKey: UInt8 = 0
    }
    
    var ariseloaderCount: Int {
        get {
            guard let value = objc_getAssociatedObject(self, &AriseLoaderAssociatedKeys.stateKey) as? Int else {
                return 0
            }
            return value
        }
        set(newValue) {
            objc_setAssociatedObject(self, &AriseLoaderAssociatedKeys.stateKey, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
}

final class AriseLoaderContainer: UIView {
    
    static func showHUDAddedTo(view: UIView, fromFederal: Bool) {
        let hud = self.hudForView(view: view)
        if (hud != nil) {
           // already there in stack
        }
        else {
            // temp fix
            let applicationFrame = view.bounds
            let hud = AriseLoaderContainer.init(frame:  applicationFrame)
            let loader = AriseSpinnerView.init(frame:  CGRect(x: 0, y: 0, width: 40, height: 40))
            
            loader.center = hud.center
            hud.addSubview(loader)
//            let label = UILabel.init(frame: CGRect(x: 5, y: loader.center.y + 20 + 15, width: applicationFrame.width - 10, height: 100))
//            label.numberOfLines = 0
//            label.font = UIFont.systemFont(ofSize: 14.0)
//            label.lineBreakMode = .byWordWrapping
//            label.textAlignment = .center
//            label.textColor = UIColor.black
//            label.text = "Please wait..".coreLocalized
//            label.sizeToFit()
//            var labelFrame = label.frame
//            labelFrame = CGRect(x: labelFrame.minX, y: labelFrame.minY, width: applicationFrame.width - 10, height: labelFrame.height)
//            label.frame = labelFrame
//            hud.addSubview(label)
            hud.backgroundColor = .white
            view.addSubview(hud)
        }
        
    }

    static func hideHUDForView(view: UIView) {
        let hud = self.hudForView(view: view)
        if (hud != nil) {
            hud!.removeFromSuperview()
        }
    }

    static func hudForView(view: UIView) -> AriseLoaderContainer? {
        let subviewsEnum = view.subviews.reversed()
        for subview in subviewsEnum {
            if subview.isKind(of: AriseLoaderContainer.self) {
                return subview as? AriseLoaderContainer
            }
        }
        return nil
    }
    
    static func incrementLoaderCount(view: UIView, fromFederal: Bool) {
        let count = currentLoaderCount(view: view) + 1
        view.ariseloaderCount = count
        refreshLoaderCount(view: view, fromFederal: fromFederal)
        
    }
    
    static func decrementLoaderCount(view: UIView) {
        let count = currentLoaderCount(view: view)
        if count > 0 {
            view.ariseloaderCount = count - 1
        }
        refreshLoaderCount(view: view)
    }
    
    static func refreshLoaderCount(view: UIView, fromFederal: Bool = false) {
        let count = currentLoaderCount(view: view)
        if count <= 0 {
            hideHUDForView(view: view)
        }
        else {
            showHUDAddedTo(view: view, fromFederal: fromFederal)
        }
    }
    
    static func currentLoaderCount(view: UIView) -> Int {
        return view.ariseloaderCount
    }
    
    static func resetLoaderCount(view: UIView) {
        view.ariseloaderCount = 0
        refreshLoaderCount(view: view)
    }
}

final class AriseSVProgressHUD  {
    
    static func show(currentViewController : UIViewController, fromFederal: Bool = false)  {
        AriseLoaderContainer.incrementLoaderCount(view: currentViewController.view, fromFederal: fromFederal)
    }
  
    static func dismiss(currentViewController : UIViewController) {
        AriseLoaderContainer.decrementLoaderCount(view: currentViewController.view)
    }
    
    static func isHUDVisible(currentViewController : UIViewController) -> Bool {
        return AriseLoaderContainer.currentLoaderCount(view: currentViewController.view) > 0
    }
    static func setDefaultMaskType(_ colour : UIColor = .clear){
//        bgView.backgroundColor = colour
//        bgView.alpha = 0.5
    }
    static func resetLoaderCount(currentViewController : UIViewController) {
        AriseLoaderContainer.resetLoaderCount(view: currentViewController.view)
    }
}

