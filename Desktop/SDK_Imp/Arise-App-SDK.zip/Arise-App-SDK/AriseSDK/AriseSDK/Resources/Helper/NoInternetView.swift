//
//  NoInternetView.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 19/07/21.
//

import Foundation
import UIKit

class NoInternetView: UIView {
    
    var buttonAction: (()->Void)?
    
    lazy var backButton: UIButton = {
      let backButton = UIButton(type: .custom)
        backButton.frame = CGRect(x: (UIScreen.main.bounds.width - 300)/2, y: UIScreen.main.bounds.height - 100, width: 300, height: 40)
        backButton.backgroundColor = UIColor.ccPrimaryColor
        backButton.setTitle("BACK TO MIB APP", for: .normal)
        backButton.addTarget(self, action: #selector(NoInternetView.pressed), for: .touchUpInside)
        backButton.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        backButton.layer.cornerRadius = 8
        backButton.clipsToBounds = true
      return backButton
    }()
    
    @objc func pressed(sender: UIButton!) {
        DispatchQueue.main.async {
            if let buttonAction = self.buttonAction {
                buttonAction()
            }
        }
    }
    
    lazy var contentView: UIImageView = {
        let contentView = UIImageView(frame: CGRect(x: 0, y: 0, width: 180, height: 180))
        contentView.contentMode = .scaleAspectFit
        contentView.center = CGPoint(x: self.center.x, y: self.center.y - 60)
        contentView.image = UIImage(named: "noInternetIcon")
        return contentView
    }()
    
    lazy var headerTitle: UILabel = {
        let headerTitle = UILabel(frame: CGRect(x: 0, y: contentView.frame.maxY + 10, width: self.bounds.maxX, height: 40))
      headerTitle.font = UIFont.systemFont(ofSize: 28, weight: .bold)
      headerTitle.text = "Oops!"
      headerTitle.textAlignment = .center
      headerTitle.textColor = UIColor.ccPrimaryColor
      return headerTitle
    }()
    
    lazy var subTitle: UILabel = {
        let subTitle = UILabel(frame: CGRect(x: 0, y: headerTitle.frame.maxY + 10, width: self.bounds.maxX, height: 40))
        subTitle.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        subTitle.text = "Failed to fetch your Arise details."
        subTitle.textAlignment = .center
        subTitle.numberOfLines = 0
        subTitle.lineBreakMode = .byWordWrapping
        subTitle.textColor = UIColor.black
        return subTitle
       }()
    
    override init(frame: CGRect) {
      super.init(frame: frame)
      setUpView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setUpView() {
     
        backgroundColor = .white
        addSubview(contentView)
        addSubview(backButton)
        addSubview(headerTitle)
        addSubview(subTitle)
    }
}
