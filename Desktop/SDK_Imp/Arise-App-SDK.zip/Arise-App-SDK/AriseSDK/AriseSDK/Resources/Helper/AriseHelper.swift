//
//  AriseHelper.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 19/07/21.
//

import Foundation
import UIKit

public struct Constants {
    public static let BUNDLE_IDENTIFIER: String = "com.nuclei.AriseSDK"
    static let REVOKE_TOKEN_API_REQUEST_KEY: String = "revokeTokenApiRequestData"
    static let PROVISIONAL_TOKEN_KEY:String = "provisional_token"
}



struct AriseConnectivity {
    static let sharedInstance = AriseNetworkReachabilityManager()!
    static var isConnectedToInternet:Bool {
        return self.sharedInstance.isReachable
    }
}

extension Dictionary {
    var json: String {
        let invalidJson = "Not a valid JSON"
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: self, options: .prettyPrinted)
            return String(bytes: jsonData, encoding: String.Encoding.utf8) ?? invalidJson
        } catch {
            return invalidJson
        }
    }
}

public struct AriseDeviceDetail {
    // MARK: Device model
    // The model of device
    
    static public let DEVICE_TYPE = "ios"
    
    static public var model: String {
        return UIDevice.current.modelName
    }

    // The version of running OS in the device. (e.g. 9.0, 10.0.)
    static public var osVersion: String {
        return UIDevice.current.systemVersion
    }
    
    public static func appVersion() -> String {
        return Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? ""
    }
    
    public static func build() -> String {
        return Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? ""
    }
    
    static func fullVersionString() -> String {
        let version = self.appVersion()
        let build = self.build()
        return "\(version) (\(build))"
    }
    
    public static func infoBundleValueForKey(_ key: String) -> String {
        return Bundle.main.infoDictionary?[key] as? String ?? ""
    }
    
    public static func sdkVersion() -> String {
        return Bundle(identifier:Constants.BUNDLE_IDENTIFIER)?.infoDictionary?["CFBundleShortVersionString"] as? String ?? ""
    }
}

public extension UIDevice {
    var modelName: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        return identifier
    }
}

extension Encodable {
  var dictionary: [String: String]? {
    guard let data = try? JSONEncoder().encode(self) else { return nil }
    return (try? JSONSerialization.jsonObject(with: data, options: .allowFragments)).flatMap { $0 as? [String: String] }
  }
}
