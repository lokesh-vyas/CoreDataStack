//
//  AriseLogger.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 20/08/21.
//

import Foundation

struct AriseLogger {
    
    // Debug Logs
    func LogD(value:Any) {
        #if DEBUG
         print("Arise::",value)
        #else
        #endif
    }
    
    // Information Logs
    func LogI(value:Any){
        if AriseCoreSetup.sharedInstance.getAriseSDKLogsEnable == "1" {
            print("Arise::",value)
        }
    }
}
