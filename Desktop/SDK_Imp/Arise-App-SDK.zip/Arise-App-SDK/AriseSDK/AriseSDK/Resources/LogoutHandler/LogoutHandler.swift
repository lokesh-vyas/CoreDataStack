//
//  LogoutHandler.swift
//  LogoutHandler
//
//  Created by Lokesh Vyas on 13/09/21.
//

import Foundation

struct LogoutHandler {
    // Internal Logout without call back for MIB
    func InternalLogout() {
        RevokeSession().revokeTokenAPICall()
        AriseMemStore.sharedInstance.clearAll()
    }
    
    func Logout() {
        RevokeSession().revokeTokenAPICall()
        AriseMemStore.sharedInstance.clearAll()
        AriseConfiguration.sharedInstance.configDelegate?.onAriseSdkLoggedOut()
        AriseConfiguration.sharedInstance.coordinator?.closeArise()
    }
}
