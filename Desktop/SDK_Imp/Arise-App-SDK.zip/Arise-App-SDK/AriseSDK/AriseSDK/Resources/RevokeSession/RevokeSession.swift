//
//  RevokeSession.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 24/12/21.
//

import Foundation

struct RevokeSession {
    
    func revokeTokenAPICall() {
        let revokeStringData = AriseMemStore.sharedInstance.getValue(key: Constants.REVOKE_TOKEN_API_REQUEST_KEY)
        guard revokeStringData != "" else {
            AriseLogger().LogI(value: "logOut call without revokeTokenAPICall")
            return
        }
        
        if let data = revokeStringData.data(using: .utf8) {
            do{
                let dictData = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String:Any]
                if let dictionaryData = dictData {
                    RevokeSession().revokeSessionToken(ariseAPIRequestData: dictionaryData)
                }
            }
            catch {
                AriseLogger().LogI(value: error)
            }
        }
    }
    
    func revokeSessionToken(ariseAPIRequestData: [String:Any]) {
        
        if let url = ariseAPIRequestData["url"] as? String, let apiUrl = URL(string: url) {
            var urlRequest = URLRequest(url: apiUrl)
            urlRequest.httpMethod = "POST"
            urlRequest.addValue("application/json", forHTTPHeaderField: "content-type")
            
            if let headers = ariseAPIRequestData["header_map"] as? [String:String] {
                for (key, value) in headers {
                    urlRequest.setValue(value, forHTTPHeaderField: key)
                }
            }
            
            let session = URLSession.shared
            let task = session.dataTask(with: urlRequest) {
                (data, response, error) in
                DispatchQueue.main.async {
                    if error != nil {
                        AriseLogger().LogI(value: "RevokeApi :Revoke API failure \(String(describing: error))")
                    } else {
                        AriseLogger().LogI(value: "RevokeApi :Revoke API Success")
                    }
                }
            }
            task.resume()
        }
    }
}

