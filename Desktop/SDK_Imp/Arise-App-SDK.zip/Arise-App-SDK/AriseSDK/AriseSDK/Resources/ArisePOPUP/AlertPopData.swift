//
//  AlertPopData.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 24/08/21.
//

import Foundation

// AlertCtaCallback Protocol
public protocol AlertCtaCallback: AnyObject {
   func onPrimaryCTAClicked()
   func onSecondaryCTAClicked()
}

// Data for Alert Pop Up
public class AlertPopupData : NSObject {
    
    var title: String?
    
    var body: String?
    
    var primaryCtaData: CTAData?
    
    var secondaryCtaData: CTAData?
    
    var isBackPressDisable: Bool?
    
    var isTouchOutSideDisable: Bool?
    
    weak var alertCtaCallback: AlertCtaCallback?
    
    public init( title:String?, body:String?,
        primaryCtaData:CTAData?, secondaryCtaData:CTAData?,
        isBackPressDisable:Bool?, isTouchOutSideDisable:Bool?,
        alertCtaCallback:AlertCtaCallback?) {
        self.title = title
        self.body = body
        self.primaryCtaData = primaryCtaData
        self.secondaryCtaData = secondaryCtaData
        self.isBackPressDisable = isBackPressDisable
        self.isTouchOutSideDisable = isTouchOutSideDisable
        self.alertCtaCallback = alertCtaCallback
    }
}

// CTA Data for Button
public class CTAData {
    var label: String
    public init(label: String) {
        self.label = label;
    }
}


