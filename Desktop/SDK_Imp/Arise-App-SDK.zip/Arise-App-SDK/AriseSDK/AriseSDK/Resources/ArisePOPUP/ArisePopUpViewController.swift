//
//  ArisePopUpViewController.swift
//  ArisePopUpViewController
//
//  Created by Lokesh Vyas on 03/09/21.
//

import UIKit

class ArisePopUpViewController: UIViewController {
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var alertPopUpView: UIView!
    @IBOutlet weak var labelDetail: UILabel!
    @IBOutlet weak var labelHeading: UILabel!
    @IBOutlet weak var secondButton: UIButton!
    @IBOutlet weak var primaryButton: UIButton!
    
    var alertPopupData : AlertPopupData?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUpUIBuilder()
        // Do any additional setup after loading the view.
    }
    
    private func setUpUIBuilder() {
        self.view.backgroundColor = .clear
        self.labelHeading.text = alertPopupData?.title
        self.labelDetail.text = alertPopupData?.body
        self.primaryButton.setTitle(alertPopupData?.primaryCtaData?.label, for: .normal)
        if alertPopupData?.secondaryCtaData == nil {
            self.secondButton.isHidden = true
        } else {
            self.secondButton.setTitle(alertPopupData?.secondaryCtaData?.label, for: .normal)
        }
        if alertPopupData?.isTouchOutSideDisable == false {
            self.backView.addTapGesture(tapNumber: 1, target: self, action: #selector(backViewTap))
        }
    }

    @objc private func backViewTap(){
        AriseLogger().LogD(value: "backViewTap")
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func buttonPrimaryTap(_ sender: Any) {
        if AriseConfiguration.sharedInstance.configDelegate?.isUserSessionValid() == true {
            AriseConfiguration.sharedInstance.configDelegate?.onAriseHeartBeat()
            IdleTimeOutManager.sharedInstance.startTimer()
            self.dismiss(animated: true, completion: nil)
        } else {
            AriseLogger().LogD(value: "buttonPrimaryTap")
            self.presentingViewController?
                .presentingViewController?.dismiss(animated: true, completion: nil)
            AriseConfiguration.sharedInstance.configDelegate?.onSessionExpired()
            LogoutHandler().Logout()
        }
    }
    
    @IBAction func buttonSecondTap(_ sender: Any) {
        AriseLogger().LogD(value: "buttonSecondTap")
    }
}

extension UIView {
  func addTapGesture(tapNumber: Int, target: Any, action: Selector) {
    let tap = UITapGestureRecognizer(target: target, action: action)
    tap.numberOfTapsRequired = tapNumber
    addGestureRecognizer(tap)
    isUserInteractionEnabled = true
  }
}
