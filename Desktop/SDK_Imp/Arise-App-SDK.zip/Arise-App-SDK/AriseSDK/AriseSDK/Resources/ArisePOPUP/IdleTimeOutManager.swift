//
//  IdleTimeOutManager.swift
//  IdleTimeOutManager
//
//  Created by Lokesh Vyas on 08/09/21.
//

import Foundation


class IdleTimeOutManager {
    
    struct Static
    {
        static var instance: IdleTimeOutManager?
    }

    var sessionTimer:Timer?
    var timeOutTriggerTime = AriseCoreSetup.sharedInstance.getPopUpTriggerTimeInSec
    
    class var sharedInstance: IdleTimeOutManager
    {
        if Static.instance == nil
        {
            Static.instance = IdleTimeOutManager()
        }
        return Static.instance!
    }
    
    init() {}
    
    @objc func startTimer() {
        sessionTimer = Timer.scheduledTimer(withTimeInterval: self.timeOutTriggerTime, repeats: true, block: { timer in
            self.showTimeOutPopUp()
        })
    }
    
    func resetTimer() {
        self.sessionTimer?.invalidate()
        self.startTimer()
    }
    
    func onHeartBeat() {
        self.resetTimer()
    }
    
    func cancelTimer() {
        self.sessionTimer?.invalidate()
        self.sessionTimer = nil
    }
    
    func showTimeOutPopUp() {
        self.cancelTimer()
        AriseConfiguration.sharedInstance.coordinator?.showAlertPopUp()
    }
}
