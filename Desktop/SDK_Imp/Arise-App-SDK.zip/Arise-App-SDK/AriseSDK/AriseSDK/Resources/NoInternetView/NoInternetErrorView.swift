//
//  NoInternetErrorView.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 25/08/21.
//

import UIKit

@IBDesignable
class NoInternetErrorView: UIView {
    
    @IBOutlet weak var msgLbl: UILabel!
    @IBOutlet weak var headLbl: UILabel!
    @IBOutlet weak var view: UIView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var arcView: UIView!
    var closeAction: (()->Void)?
    var retryAction: (()->Void)?
    
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var retryButton: UIButton!
    
    private func nibSetup() {
        self.view = loadViewFromNib()
        view.frame = bounds
        view.backgroundColor = UIColor.white
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.translatesAutoresizingMaskIntoConstraints = true
        addSubview(view)
    }

    func setUpUI(msgString:String) {
        self.headLbl.text = "Oops!".coreLocalized
        self.msgLbl.text = msgString
        self.closeButton.setTitle("Close".coreLocalized, for: .normal)
        self.retryButton.setTitle("Retry".coreLocalized, for: .normal)
    }
    
    private func loadViewFromNib() -> UIView {
        let thisName = String(describing: type(of: self))
        let view = Bundle(for: self.classForCoder).loadNibNamed(thisName, owner: self, options: nil)?.first as! UIView
        return view
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        nibSetup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    @IBAction func retryAction(_ sender: Any) {
        DispatchQueue.main.async {
            if let buttonAction = self.retryAction {
                buttonAction()
            }
        }
    }
    
    @IBAction func closeAction(_ sender: Any) {
        DispatchQueue.main.async {
            if let buttonAction = self.closeAction {
                buttonAction()
            }
        }
    }
}


