//
//  CoreLanguageHandler.swift
//  CoreLanguageHandler
//
//  Created by Lokesh Vyas on 13/09/21.
//

import Foundation
import UIKit

let defaultLanguage = "default" // picks default language set
let englishLanguage = "en"
let arabicLanguage = "ar"

@objc enum PreferredLocalization: Int, RawRepresentable {
    case `default` = 0  // picks default language set
    case english
    case arabic
    
    // extend any other language
    public typealias RawValue = String
    
    public var rawValue: RawValue {
        switch self {
        case .`default`: return defaultLanguage
        case .english: return englishLanguage
        case .arabic: return arabicLanguage
        }
    }
    
    public init?(rawValue: RawValue) {
        switch rawValue {
        case defaultLanguage:
            self = .default
        case englishLanguage:
            self = .english
        case arabicLanguage:
            self = .arabic
        default:
            self = .default
        }
    }
    
}

private let PreferredLanguageKey = "PreferredLanguage"

class CoreLanguageHandler: NSObject {
    
    static let `default` = CoreLanguageHandler()
    
    var preferredLocalization: PreferredLocalization {
        set {
            if currentLocalization != newValue {
                currentLocalization = newValue
                updateFromCurrentLocalization()
                alignContentAttribute()
                alignContentAttribute()
            }
        }
        get {
            return currentLocalization
        }
    }
    
    private var currentLocalization: PreferredLocalization = .arabic
    private(set) var currentBundle: Bundle = Bundle.localizationFramework
    private(set) var currentLocale: Locale = Locale.current
    
    override init() {
        super.init()
        loadCurrentLocalizationIfNeeded()
        alignContentAttribute()
    }
    
    private func alignContentAttribute() {
        if currentLocalization ==  PreferredLocalization.arabic {
            UIView.appearance().semanticContentAttribute = .forceRightToLeft
        }else{
            UIView.appearance().semanticContentAttribute = .forceLeftToRight
        }
    }
    
    private func loadCurrentLocalizationIfNeeded() {
        if let key = UserDefaults.standard.string(forKey: PreferredLanguageKey),
            let localization = PreferredLocalization(rawValue: key) {
            preferredLocalization = localization
        }
        loadCurrentBundleAndLocale()
    }
    
    private func updateFromCurrentLocalization() {
        loadCurrentBundleAndLocale()
        UserDefaults.standard.setValue(currentLocalization.rawValue, forKey: PreferredLanguageKey)
    }
    
    func localizedString(_ key: String) -> String {
        /*
        if currentLocalization == .default {
            return NSLocalizedString(key, comment: "")
        }
        */
        return currentBundle.localizedString(forKey: key, value: nil, table: nil)
    }
    
    private func loadCurrentBundleAndLocale() {
        loadCurrentBundle()
        loadCurrentLocale()
    }
    
    private func loadCurrentBundle() {
        var bundle: Bundle?
        if preferredLocalization != .default {
            let key = currentLocalization.rawValue
            if let path = Bundle(identifier: Constants.BUNDLE_IDENTIFIER)?.path(forResource: key + ".lproj/Localizable", ofType: "plist") {
                bundle = Bundle(path: path)
            }
        }
        currentBundle = bundle ?? Bundle(identifier: Constants.BUNDLE_IDENTIFIER)!
    }
    
    private func loadCurrentLocale() {
        var locale: Locale?
        if currentLocalization != .default {
            locale = Locale(identifier: currentLocalization.rawValue)
        }
        currentLocale = locale ?? Locale.current
    }
}

extension String {
    public var coreLocalized: String {
        return Bundle.localizationFramework.localizedString(forKey: self,value: "\(self)",table: nil)
    }
}

extension Bundle {
    static var localizationFramework: Bundle {
        guard let localizationBundle = Bundle(identifier: Constants.BUNDLE_IDENTIFIER) else { return .main }

        guard
            let bundlePath = localizationBundle.path(forResource: currentLanguage(of: localizationBundle),ofType: "lproj"),
            let bundle = Bundle(path: bundlePath) else { return .main }

        return bundle
    }

    static func currentLanguage(of bundle: Bundle) -> String {
        return String(AriseCoreSetup.sharedInstance.preferredLocalization.rawValue)
    }
}
