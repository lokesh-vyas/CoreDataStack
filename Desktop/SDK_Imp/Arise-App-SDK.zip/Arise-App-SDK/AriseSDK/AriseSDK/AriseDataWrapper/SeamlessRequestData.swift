//
//  SeamlessRequestData.swift
//  SeamlessRequestData
//
//  Created by Lokesh Vyas on 30/08/21.
//

import Foundation

public class SeamlessRequestData : NSObject,Encodable {
    
    var osVersion: String?
    var deviceVersion: String?
    var deviceType: String?
    var appVersion: String?
    var tenantAppVersion: String?
    var fcmToken: String?
    var partnerKey: String?
    var deviceId: String?
    
    private enum CodingKeys : String, CodingKey {
        case osVersion        = "os_version"
        case deviceVersion    = "device_version"
        case deviceType       = "device_type"
        case appVersion       = "app_version"
        case tenantAppVersion = "tenant_app_version"
        case fcmToken         = "fcm_token"
        case partnerKey       = "tenant_key"
        case deviceId         = "device_id"
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(osVersion, forKey: .osVersion)
        try container.encode(deviceVersion, forKey: .deviceVersion)
        try container.encode(deviceType, forKey: .deviceType)
        try container.encode(appVersion, forKey: .appVersion)
        try container.encode(tenantAppVersion, forKey: .tenantAppVersion)
        try container.encode(fcmToken, forKey: .fcmToken)
        try container.encode(partnerKey, forKey: .partnerKey)
        try container.encode(deviceId, forKey: .deviceId)
    }
}


struct ParentAppCommunicationHandler {

    func initiateSeamlessRequest() -> SeamlessRequestData {
        let seamlessRequestData = SeamlessRequestData()
        
        seamlessRequestData.partnerKey = AriseCoreSetup.sharedInstance.partnerKey
        seamlessRequestData.deviceId =  AriseCoreSetup.sharedInstance.getDeviceID
        seamlessRequestData.appVersion = AriseDeviceDetail.sdkVersion()
        seamlessRequestData.tenantAppVersion = AriseDeviceDetail.appVersion()
        seamlessRequestData.osVersion = AriseDeviceDetail.osVersion
        seamlessRequestData.deviceVersion = AriseDeviceDetail.model
        seamlessRequestData.deviceType = AriseDeviceDetail.DEVICE_TYPE
        seamlessRequestData.fcmToken = AriseCoreSetup.sharedInstance.getFCMToken
        
        return seamlessRequestData
    }
}
