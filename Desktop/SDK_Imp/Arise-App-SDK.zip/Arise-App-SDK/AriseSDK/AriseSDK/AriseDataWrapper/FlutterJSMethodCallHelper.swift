//
//  FlutterJSMethodCallHelper.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 20/08/21.
//

import Foundation

class FlutterJSMethodCallHelper {
    
    
    @objc func sendPartnerApplicationData() -> String {
        
        let tenantKey: String = AriseCoreSetup.sharedInstance.partnerKey
        let deviceID : String = AriseCoreSetup.sharedInstance.getDeviceID
        let shouldEnableLogs = AriseCoreSetup.sharedInstance.getAriseSDKLogsEnable
        let locale: String = AriseCoreSetup.sharedInstance.preferredLocalization.rawValue
        let additionalData: String = AriseCoreSetup.sharedInstance.additionalData.json
      
        let configJson = FileUtility.loadJSON(path: FileUtility.getPath(name: (AriseCoreSetup.sharedInstance.getAriseFASMConfig?.cacheName)!), withFilename: (AriseCoreSetup.sharedInstance.getAriseFASMConfig?.cacheName)! + "_json.json")
        
        var webSdkVersion = ""
        if let currentSemanticMajorAppVersion = (AriseCoreSetup.sharedInstance.getAriseFASMConfig?.hostVersion?.major()) {
             webSdkVersion = configJson.getWebVersion(appVersion: currentSemanticMajorAppVersion)
        }
        
        let partnerDict:[String:String] = ["tenantKey":tenantKey,
                                           "deviceId":deviceID,
                                           "appVersion":AriseDeviceDetail.sdkVersion(),
                                           "tenantAppVersion":AriseDeviceDetail.appVersion(),
                                           "osVersion":AriseDeviceDetail.osVersion,
                                           "deviceVersion":AriseDeviceDetail.model,
                                           "shouldEnableLogs":shouldEnableLogs,
                                           "environment":AriseCoreSetup.sharedInstance.getEnvironment,
                                           "locale":locale,
                                           "webSdkVersion" : webSdkVersion,
                                           "additionalData":additionalData
        ]
        AriseLogger().LogD(value:partnerDict.json)
        return partnerDict.json
    }
    
}

extension AriseWebViewController {
    // SEND provisionalToken to Web SDK
    
    @objc func sendProvisonTokenData(token:String) {
        AriseLogger().LogI(value: "---> provisionalToken(\(token)")
        self.webView?.evaluateJavaScript("validateProvisionalToken('\(token)')",
                                         completionHandler: nil)
    }
    
    func fetchProvisonTokenFailed(error:String) {
        self.webView?.evaluateJavaScript("onProvisionalTokenApiFailed('\(error)')", completionHandler: nil)
    }
}
