//
//  KeychainWrapper.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 03/08/21.
//

import Foundation

class AriseMemStore : NSObject {
    
    private var inMemeStore = [String:String]()
    static let sharedInstance = AriseMemStore()
    private override init() {}
   
    func getValue(key:String) -> String {
        return AriseMemStore.sharedInstance.inMemeStore[key] ?? ""
    }
    
    func putValue(key:String,value:String) {
        AriseMemStore.sharedInstance.inMemeStore[key] = value
    }
    
    func remove(key:String) {
        AriseMemStore.sharedInstance.inMemeStore.removeValue(forKey: key)
    }
    
    func clearAll() {
        AriseMemStore.sharedInstance.inMemeStore.removeAll()
    }
}

