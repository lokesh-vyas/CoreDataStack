//
//  ArisePartnerConfig.swift
//  AriseSDK
//
//  Created by Lokesh Vyas on 09/07/21.
//

import Foundation
import UIKit

class AriseCoreSetup : NSObject {
    struct Static
    {
        static var instance: AriseCoreSetup?
    }
    
    class var sharedInstance: AriseCoreSetup
    {
        if Static.instance == nil
        {
            Static.instance = AriseCoreSetup()
        }
        return Static.instance!
    }
    
    override init() {}
    
    var partnerKey: String = ""
    var getEnvironment: String = "staging"
    var getDeviceID: String = ""
    var getFCMToken: String = ""
    var getAriseSDKLogsEnable: String = "0"
    var getAriseSDKUrl: String = ""
    var setAriseSDKUrl: String = ""
    var getAriseFASMConfig: FasmConfig?
    var getAriseSDKDirectory: String = ""
    var getPopUpTriggerTimeInSec: Double = 0.0
    var getMaxSessionTimeOutTimeInSec: Double = 0.0
    var additionalData: [String:String] = ["":""]
    var preferredLocalization : PreferredLocalization =  .english
}

@objc public protocol NucleiArisePartnerConfig: AnyObject {
    
    /**
     * SDK checks this method whenever a deep link, any method to start or open Arise service is executed.
     * If this method returns false, the SDK won't let users access any Arise related services.
     */
    @objc func isPartnerApplicationLoggedIn() -> Bool
    /**
     * This callback will be called by the Arise SDK, if the Arise SDK is not logged in.
     * Need to initiate Seamless login flow by MIB.
     * */
    func onAriseSdkSeamlessLoginRequest(seamlessRequestData:[String:String])
    
    /**
     * This protocol will be used for MPIN authentication flow
     */
    
    @objc func onAriseAuthenticationRequest()
    
    /**
     * This protocol will be used for MPIN authentication flow
     */
    
    @objc func onAriseAuthenticationError()
    /**
     * This callback will be called by Arise SDK when notify partner app on login failure
     */
    @objc func ariseSeamlessLoginDidFail(_ error: NSError) -> Void
    
    /**
     * This callback will be called by Arise SDK when notify partner app on login success
     */
    
    @objc func ariseSeamlessLoginDidSucceed() -> Void
    
    /**
     * Whenever the user interaction happens in Arise Sdk, this method will be called
     * */
    @objc func onAriseHeartBeat() -> Void
    
    /**
     * This callback will be called by Arise SDK to get User session is Expired.
     */
    
    func onSessionExpired()
    /**
     * This callback will be called by Arise SDK to get User is session is valid.
     */
    func isUserSessionValid() -> Bool
    /**
     * This callback will be called by Arise SDK, if the MIB app not logged in
     * */
    @objc func onUserLoginRequest(deeplink: String) -> Void
    
    /**
     * This will be called by the SDK when the user logs out of Arise SDK.
     * */
    @objc func onAriseSdkLoggedOut() -> Void
    
    /**
     * This callback will be called by Arise SDK when the user voluntarily quits the Arise SDK
     * (Ex: clicking back, Home button and exiting all screens).
     */
    @objc func onAriseSDKExit(data:[String:String]) -> Void
}
