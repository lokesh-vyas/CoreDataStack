# arise-ios-sdk
This is iOS Native wrapper SDK for Flutter Arise SDK which acts as communicator between Parant App and Arise Flutter SDK.
